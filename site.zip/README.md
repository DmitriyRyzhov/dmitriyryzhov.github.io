# Cogle

Статический сайт онлайн-утилит (HTML + CSS + vanilla JS). Без сборки — открывается напрямую из `file://`.

## Структура
```
index.html          — главная, сетка всех инструментов
privacy.html        — политика конфиденциальности
favicon.svg, img/logo.svg
css/style.css       — общие стили
js/common.js        — общие функции (fmt, toast, copyText)
js/hash-lib.js      — чистый JS MD5/SHA-1/SHA-256 (также экспортируется для Node)
js/tools/*.js       — логика каждого инструмента (timestamp-fmt.js — общая библиотека форматов дат)
js/vendor/qrcode.js — QR-энкодер (MIT, Kazuhiko Arase)
js/vendor/xlsx.full.min.js — SheetJS CE 0.20.3 (Apache-2.0, лицензия в js/vendor/xlsx.LICENSE.txt); подключается только на tools/data-converter.html
js/tools/data-lib.js — CSV (RFC 4180), flatten/unflatten, JSON-ошибки с позицией (тестируется в Node)
js/tools/mortgage-calc.js, compound-calc.js — расчёты без DOM (тестируются в Node)
js/tools/symbols.js — массив BLOCKS: добавьте объект {title, items:[[символ, "название"]]} чтобы добавить блок символов
tools/*.html        — страницы инструментов
```
Шапка и подвал продублированы в каждой странице (помечены комментариями HEADER/FOOTER — в будущем вынести в include).
Рекламные блоки (AdSense/РСЯ) — закомментированные `div.ad-slot` под шапкой и после контента.

## Генерация страниц
Все HTML-страницы генерируются скриптом `gen.py` (лежит рядом с папкой сайта: `/workspace/gen.py`):
шапка, подвал и рекламные слоты берутся из функции `page()`, поэтому правки лучше вносить туда и перегенерировать (`python3 gen.py`).

## Как добавить инструмент
1. В `gen.py` добавьте кортеж в список `TOOLS`: `("my-tool", "🔧", "Название", "Короткое описание")`.
   Иконка — эмодзи, которое отображается в Windows (избегайте новых, например 🪙), либо `<img>`.
2. Добавьте разметку в `B["my-tool"]` и список скриптов в `JS["my-tool"]` (например `["js/tools/my-tool.js"]`; общий `js/common.js` подключается автоматически).
3. Добавьте id инструмента в нужную группу списка `GROUPS` (Калькуляторы, Текст, Конвертеры и даты, Генераторы, Игры и случайность, Преобразование данных)
   или создайте новую группу `("anchor", "🔧 Заголовок", ["my-tool"])` — она автоматически появится на главной отдельной колонкой (описание инструмента показывается во всплывающей подсказке).
   Скрипт проверяет, что каждый инструмент входит ровно в одну группу.
4. Создайте `js/tools/my-tool.js` (IIFE, `'use strict'`) и запустите `python3 gen.py`.

Без генератора: скопируйте любую страницу из `tools/`, поменяйте `<title>`, описание, содержимое `<main>` и скрипты (пути с `../`),
затем добавьте карточку `<a class="card" href="tools/my-tool.html">…</a>` в нужную секцию `<section class="group">` на `index.html`.

## SEO
- Тексты SEO (title ≤ 60, description ≤ 160, H1, «Как пользоваться», пример, FAQ) — в `seo.py` рядом с `gen.py`. FAQ из одного источника выводится на странице и в JSON-LD `FAQPage`.
- **Перед публикацией замените `SITE_URL = "https://example.com"` в `gen.py` на реальный домен** и перегенерируйте (`cd site && python3 ../gen.py`): от него зависят canonical, Open Graph, JSON-LD, `sitemap.xml` и `robots.txt`.
- Каждая страница инструмента: canonical, meta robots, Open Graph/Twitter (картинка `img/og.png` 1200×630), JSON-LD `WebApplication` + `FAQPage` + `BreadcrumbList`, блок «Похожие инструменты» (сначала из той же группы). Главная: `WebSite` + `ItemList`.
- `sitemap.xml` (дата `LASTMOD` в gen.py), `robots.txt`, `404.html` (noindex). На хостинге укажите 404.html как страницу ошибки.
- Новому инструменту нужна запись в `SEO` (seo.py) — иначе gen.py остановится с ошибкой.
