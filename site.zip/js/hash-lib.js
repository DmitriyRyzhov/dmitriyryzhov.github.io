/* Чистые JS-реализации MD5, SHA-1, SHA-256 (работают и из file://, где нет crypto.subtle).
   Вход: Uint8Array, выход: hex-строка. */
(function(root){
  'use strict';
  function hex(words, le){ var s=''; for(var i=0;i<words.length;i++){ for(var j=0;j<4;j++){ var sh=le?j*8:(3-j)*8; s+=('0'+((words[i]>>>sh)&255).toString(16)).slice(-2);} } return s; }
  /** Дополнение сообщения до кратного 64 байтам; le — длина little-endian (MD5) */
  function pad(bytes, le){
    var n=bytes.length, total=((n+8)>>6)+1, w=new Array(total*16).fill(0), i;
    for(i=0;i<n;i++) w[i>>2]|= bytes[i]<<(le?(i%4)*8:(3-i%4)*8);
    w[n>>2]|=0x80<<(le?(n%4)*8:(3-n%4)*8);
    var lo=(n*8)>>>0, hi=Math.floor(n/0x20000000);
    if(le){ w[total*16-2]=lo; w[total*16-1]=hi; } else { w[total*16-1]=lo; w[total*16-2]=hi; }
    return w;
  }
  function rol(x,c){ return (x<<c)|(x>>>(32-c)); }
  function md5(bytes){
    var K=[],S=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21],i;
    for(i=0;i<64;i++) K[i]=Math.floor(Math.abs(Math.sin(i+1))*4294967296)|0;
    var w=pad(bytes,true), a0=0x67452301,b0=0xefcdab89|0,c0=0x98badcfe|0,d0=0x10325476;
    for(var o=0;o<w.length;o+=16){
      var A=a0,B=b0,C=c0,D=d0;
      for(i=0;i<64;i++){
        var F,g;
        if(i<16){F=(B&C)|(~B&D);g=i;} else if(i<32){F=(D&B)|(~D&C);g=(5*i+1)%16;}
        else if(i<48){F=B^C^D;g=(3*i+5)%16;} else {F=C^(B|~D);g=(7*i)%16;}
        var t=D; D=C; C=B; B=(B+rol((A+F+K[i]+w[o+g])|0, S[(i>>4)*4+i%4]))|0; A=t;
      }
      a0=(a0+A)|0;b0=(b0+B)|0;c0=(c0+C)|0;d0=(d0+D)|0;
    }
    return hex([a0,b0,c0,d0],true);
  }
  function sha1(bytes){
    var w=pad(bytes,false), h=[0x67452301,0xefcdab89|0,0x98badcfe|0,0x10325476,0xc3d2e1f0|0], W=new Array(80);
    for(var o=0;o<w.length;o+=16){
      for(var t=0;t<80;t++) W[t]= t<16? w[o+t] : rol(W[t-3]^W[t-8]^W[t-14]^W[t-16],1);
      var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];
      for(t=0;t<80;t++){
        var f,k;
        if(t<20){f=(b&c)|(~b&d);k=0x5a827999;} else if(t<40){f=b^c^d;k=0x6ed9eba1;}
        else if(t<60){f=(b&c)|(b&d)|(c&d);k=0x8f1bbcdc|0;} else {f=b^c^d;k=0xca62c1d6|0;}
        var tmp=(rol(a,5)+f+e+k+W[t])|0; e=d; d=c; c=rol(b,30); b=a; a=tmp;
      }
      h[0]=(h[0]+a)|0;h[1]=(h[1]+b)|0;h[2]=(h[2]+c)|0;h[3]=(h[3]+d)|0;h[4]=(h[4]+e)|0;
    }
    return hex(h,false);
  }
  var K256=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  function ror(x,c){ return (x>>>c)|(x<<(32-c)); }
  function sha256(bytes){
    var w=pad(bytes,false), h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19].map(function(x){return x|0;}), W=new Array(64);
    for(var o=0;o<w.length;o+=16){
      for(var t=0;t<64;t++){
        if(t<16) W[t]=w[o+t];
        else { var s0=ror(W[t-15],7)^ror(W[t-15],18)^(W[t-15]>>>3), s1=ror(W[t-2],17)^ror(W[t-2],19)^(W[t-2]>>>10); W[t]=(W[t-16]+s0+W[t-7]+s1)|0; }
      }
      var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
      for(t=0;t<64;t++){
        var S1=ror(e,6)^ror(e,11)^ror(e,25), ch=(e&f)^(~e&g), t1=(hh+S1+ch+K256[t]+W[t])|0;
        var S0=ror(a,2)^ror(a,13)^ror(a,22), maj=(a&b)^(a&c)^(b&c), t2=(S0+maj)|0;
        hh=g; g=f; f=e; e=(d+t1)|0; d=c; c=b; b=a; a=(t1+t2)|0;
      }
      h[0]=(h[0]+a)|0;h[1]=(h[1]+b)|0;h[2]=(h[2]+c)|0;h[3]=(h[3]+d)|0;h[4]=(h[4]+e)|0;h[5]=(h[5]+f)|0;h[6]=(h[6]+g)|0;h[7]=(h[7]+hh)|0;
    }
    return hex(h,false);
  }
  var lib={md5:md5,sha1:sha1,sha256:sha256};
  if(typeof module!=='undefined' && module.exports) module.exports=lib; else root.HashLib=lib;
})(this);
