/* Калькулятор сложных процентов (UI); расчёт в compound-calc.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  function calc(){
    var y=Math.max(0,Math.floor(+$('years').value||0)), mo=Math.max(0,Math.floor(+$('months').value||0)), months=y*12+mo, dd=Math.max(0,Math.floor(+$('days').value||0));
    var R=CompoundCalc.compound(+$('initial').value||0,+$('rate').value||0,months,+$('freq').value,+$('monthly').value||0,dd);
    var yy=Math.floor(months/12), rm=months%12;
    $('termtxt').textContent='Срок: '+months+' мес.'+(months?' ('+[yy?yy+' г.':'',rm?rm+' мес.':''].filter(Boolean).join(' ')+')':'')+(dd?' + '+dd+' дн.':'');
    $('final').textContent=fmt(R.final)+' ₽'; $('contrib').textContent=fmt(R.contrib)+' ₽'; $('profit').textContent=fmt(R.final-R.contrib)+' ₽';
  }
  ['initial','rate','years','months','days','freq','monthly'].forEach(function(id){$(id).addEventListener('input',calc);});
  calc();
})();
