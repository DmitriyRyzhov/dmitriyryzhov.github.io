/* Генератор паролей на crypto.getRandomValues */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var SETS={lower:'abcdefghijklmnopqrstuvwxyz',upper:'ABCDEFGHIJKLMNOPQRSTUVWXYZ',digits:'0123456789',symbols:'!@#$%^&*()-_=+[]{};:,.<>?/'};
  /** Случайное целое [0,max) без смещения (rejection sampling) */
  function rnd(max){ var a=new Uint32Array(1), lim=Math.floor(0x100000000/max)*max; do{crypto.getRandomValues(a);}while(a[0]>=lim); return a[0]%max; }
  function gen(){
    var len=+$('len').value, pool='', must=[];
    Object.keys(SETS).forEach(function(k){ if($(k).checked){ pool+=SETS[k]; must.push(SETS[k]); } });
    $('lenv').textContent=len;
    if(!pool){ $('out').textContent='Выберите хотя бы один набор символов'; return; }
    var ch=must.map(function(s){return s[rnd(s.length)];}); // по символу из каждого набора
    while(ch.length<len) ch.push(pool[rnd(pool.length)]);
    for(var i=ch.length-1;i>0;i--){ var j=rnd(i+1), x=ch[i]; ch[i]=ch[j]; ch[j]=x; } // перемешивание
    $('out').textContent=ch.slice(0,len).join('');
  }
  ['len','lower','upper','digits','symbols'].forEach(function(id){$(id).addEventListener('input',gen);});
  $('gen').addEventListener('click',gen);
  $('copy').addEventListener('click',function(){copyText($('out').textContent);});
  gen();
})();
