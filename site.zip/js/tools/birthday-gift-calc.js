/* Шуточный калькулятор «Сколько скинуться коллеге на ДР» (без DOM, тестируется в Node).
   Формула из интернет-мема: Сумма = (X/500 + Y/100) × K × N */
(function(root){
  'use strict';
  var K={'0.5':'Работает не в твоём отделе','1':'В твоём отделе, но в другой функции','1.5':'В твоей функции','2':'Твой руководитель или подчинённый'};
  var N={'0.5':'Видитесь реже раза в неделю','1':'Общаетесь почти каждый день','1.5':'Вместе отдыхали на корпоративе','2':'Ходили друг к другу в гости'};
  function calc(X,Y,k,n){
    X=Math.max(0,+X||0); Y=Math.max(0,+Y||0); k=+k||0; n=+n||0;
    var exact=(X/500+Y/100)*k*n, step=exact<1000?50:100, rounded=Math.round(exact/step)*step;
    return {exact:exact,rounded:rounded,step:step,a:X/500,b:Y/100,verdict:verdict(rounded)};
  }
  function verdict(s){
    if(s<=0) return 'Тёплые слова и открытка — тоже отличный подарок!';
    if(s<200) return 'Хватит на шарик и самую искреннюю улыбку.';
    if(s<500) return 'Скромно, но со вкусом: на тортик в складчину хватит.';
    if(s<1000) return 'Солидный вклад — коллега точно заметит заботу.';
    if(s<3000) return 'Щедро! Вас запишут в лучшие друзья отдела.';
    if(s<10000) return 'Королевский размах — проверьте, не ваш ли это день рождения.';
    return 'С такой суммой коллега начнёт отмечать ДР каждый месяц!';
  }
  var api={calc:calc,verdict:verdict,K:K,N:N};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.BdayCalc=api;
})(this);
