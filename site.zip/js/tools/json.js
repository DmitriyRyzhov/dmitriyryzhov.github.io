/* JSON форматтер / валидатор */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  /** Рекурсивная сортировка ключей объектов */
  function sortKeys(v){
    if(Array.isArray(v)) return v.map(sortKeys);
    if(v&&typeof v==='object'){ var o={}; Object.keys(v).sort().forEach(function(k){o[k]=sortKeys(v[k]);}); return o; }
    return v;
  }
  /** Позиция ошибки: разные движки пишут "position N" или "line L column C" */
  function errPos(msg,text){
    var m=/line (\d+) column (\d+)/.exec(msg); if(m) return {line:+m[1],col:+m[2]};
    m=/position (\d+)/.exec(msg); if(!m) return null;
    var p=+m[1], before=text.slice(0,p).split('\n');
    return {line:before.length,col:before[before.length-1].length+1};
  }
  function parse(){
    var text=$('in').value;
    if(!text.trim()){ status('',''); return null; }
    try{ var v=JSON.parse(text); status('✔ JSON корректен','ok'); return v; }
    catch(e){
      var p=errPos(e.message,text), s='✖ Ошибка: '+e.message;
      if(p) s+=' — строка '+p.line+', столбец '+p.col;
      status(s,'err'); return undefined;
    }
  }
  function status(t,c){ var el=$('status'); el.textContent=t; el.style.color=c==='ok'?'#15803d':'#b91c1c'; }
  function run(minify){
    var v=parse(); if(v===undefined||v===null&&!$('in').value.trim()) return;
    if($('sort').checked) v=sortKeys(v);
    var ind=$('indent').value; ind= ind==='tab'?'\t':+ind;
    $('out').value= minify?JSON.stringify(v):JSON.stringify(v,null,ind);
  }
  $('fmt').addEventListener('click',function(){run(false);});
  $('min').addEventListener('click',function(){run(true);});
  $('in').addEventListener('input',parse);
  $('copy').addEventListener('click',function(){copyText($('out').value);});
})();
