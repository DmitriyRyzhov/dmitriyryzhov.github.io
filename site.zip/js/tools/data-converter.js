/* Конвертер данных: CSV / TSV / JSON / Excel -> Таблица / Дерево / JSON / CSV, выгрузка CSV/JSON/XLSX.
   Логика разбора — data-lib.js, Excel — js/vendor/xlsx.full.min.js (SheetJS CE, Apache-2.0). */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var MAX_ROWS=1000, MAX_TEXT=1000000, MAX_CHILDREN=500, WARN_BYTES=8*1024*1024;
  var EXCEL_EXT=/\.(xlsx|xls|xlsm|xlsb|ods)$/i;
  var S={data:undefined, src:'', wb:null, fileName:'', enc:'', view:'table', userView:false};
  var DL=window.DataLib;

  function escHtml(s){ return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
  function cell(v){ if(v===null) return 'null'; if(v===undefined) return ''; if(typeof v==='object') return JSON.stringify(v); return String(v); }
  function setMsg(id,t){ $(id).textContent=t||''; $(id).hidden=!t; }
  function stamp(){ var d=new Date(),p=function(n){return ('0'+n).slice(-2);}; return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
  function delim(){ var v=$('delim').value; return v==='auto'?null:(v==='tab'?'\t':v); }
  function outDelim(){ var v=$('outdelim').value; return v==='tab'?'\t':v; }
  function opts(){ return {headers:$('headers').checked, types:$('types').checked, nest:$('nest').checked}; }
  /** Даты из Excel -> ISO-строки */
  function fixDates(aoa){ return aoa.map(function(r){ return r.map(function(v){ return v instanceof Date ? v.toISOString() : v; }); }); }

  /* ---------- разбор входа ---------- */
  function parse(){
    setMsg('err',''); if(!$('warn').dataset.size) setMsg('warn','');
    var type=$('intype').value;
    try{
      if(S.wb && (type==='auto'||type==='excel')){
        var ws=S.wb.Sheets[$('sheet').value];
        S.data=DL.rowsToData(fixDates(XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:''})),opts()); S.src='Excel';
      } else {
        var text=$('input').value;
        if(!text.trim()){ S.data=undefined; S.src=''; render(); setMsg('err',S.fileName?'Файл пуст.':''); return; }
        if(type==='excel'){ throw new Error('Для Excel загрузите файл (.xlsx, .xls, .xlsm, .xlsb, .ods).'); }
        var fmt= type==='auto' ? DL.detectFormat(text) : (type==='tsv'?'csv':type);
        if(fmt==='json'){
          try{ S.data=JSON.parse(text.replace(/^\uFEFF/,'')); }catch(e){ throw new Error(DL.jsonError(e,text)); }
          S.src='JSON';
        } else {
          var d= type==='tsv' ? '\t' : (delim()||DL.detectDelimiter(text));
          S.data=DL.rowsToData(DL.parseCSV(text,d),opts());
          S.src=(d==='\t'?'TSV':'CSV')+' (разделитель «'+(d==='\t'?'Tab':d)+'»)';
        }
      }
      if(Array.isArray(S.data)&&!S.data.length) throw new Error('Нет данных: после разбора не осталось ни одной строки.');
      if(S.data===null||typeof S.data!=='object') throw new Error('Неподдерживаемая структура: ожидается объект или массив, получено '+(S.data===null?'null':typeof S.data)+'.');
    }catch(e){ S.data=undefined; setMsg('err','✖ '+e.message); }
    if(!S.userView) S.view = S.data!==undefined && tooWide() ? 'tree' : 'table';
    render();
  }
  /** Плоская таблица неразумна: слишком глубоко или слишком много колонок */
  function tooWide(){ var t=DL.toTable(S.data,200); return DL.depth(S.data)>7 || t.columns.length>200; }

  /* ---------- вывод ---------- */
  function render(){
    document.querySelectorAll('[data-view]').forEach(function(b){ b.setAttribute('aria-checked',String(b.dataset.view===S.view)); });
    var out=$('out'); out.innerHTML='';
    if(S.data===undefined){ $('info').textContent=''; return; }
    var names={table:'Таблица',tree:'Дерево',json:'JSON',csv:'CSV'};
    var count=Array.isArray(S.data)?S.data.length+' записей':'1 объект';
    $('info').textContent='Режим: '+S.src+' → '+names[S.view]+' · '+count+(S.fileName?' · файл: '+S.fileName:'')+(S.enc?' · кодировка: '+S.enc:'');
    if(S.view!=='tree'&&S.view!=='json'&&tooWide()) setMsg('warn','Данные слишком глубокие или содержат более 200 колонок после «расплющивания» — удобнее смотреть в виде «Дерево» или «JSON».');
    else if(!$('warn').dataset.size) setMsg('warn','');
    if(S.view==='table') renderTable(out);
    else if(S.view==='tree') out.appendChild(treeNode(Array.isArray(S.data)?'[массив]':'{объект}',S.data,true));
    else { var txt=S.view==='json'?JSON.stringify(S.data,null,2):DL.toCSV(DL.toAOA(S.data),outDelim()), pre=document.createElement('pre');
      pre.className='output mono dc-pre'; pre.textContent=txt.length>MAX_TEXT?txt.slice(0,MAX_TEXT):txt; out.appendChild(pre);
      if(txt.length>MAX_TEXT) note(out,'Показан первый 1 МБ текста. Копирование и скачивание содержат всё.'); }
  }
  function note(el,t){ var p=document.createElement('p'); p.className='lead dc-note'; p.textContent=t; el.appendChild(p); }
  function renderTable(out){
    var t=DL.toTable(S.data,MAX_ROWS), h=['<div class="table-wrap dc-table"><table><thead><tr><th>#</th>'];
    t.columns.forEach(function(c){ h.push('<th>'+escHtml(c)+'</th>'); });
    h.push('</tr></thead><tbody>');
    t.rows.forEach(function(r,i){ h.push('<tr><td>'+(i+1)+'</td>'); r.forEach(function(v){ h.push('<td>'+escHtml(cell(v))+'</td>'); }); h.push('</tr>'); });
    h.push('</tbody></table></div>'); out.innerHTML=h.join('');
    if(t.total>MAX_ROWS) note(out,'Показаны первые '+MAX_ROWS+' из '+t.total+' строк. Копирование и скачивание содержат все строки.');
  }
  /** Сворачиваемое дерево; дочерние узлы строятся лениво при раскрытии */
  function treeNode(key,val,open){
    if(val===null||typeof val!=='object'){
      var d=document.createElement('div'); d.className='tree-leaf';
      d.innerHTML='<span class="tk">'+escHtml(key)+':</span> <span class="tv tv-'+(val===null?'null':typeof val)+'">'+escHtml(typeof val==='string'?JSON.stringify(val):String(val))+'</span>';
      return d;
    }
    var arr=Array.isArray(val), keys=Object.keys(val), det=document.createElement('details'), sum=document.createElement('summary');
    sum.innerHTML='<span class="tk">'+escHtml(key)+'</span> <span class="tc">'+(arr?'[ '+keys.length+' ]':'{ '+keys.length+' }')+'</span>';
    det.appendChild(sum); det.className='tree-n';
    var built=false;
    function build(){ if(built) return; built=true;
      keys.slice(0,MAX_CHILDREN).forEach(function(k){ det.appendChild(treeNode(k,val[k],false)); });
      if(keys.length>MAX_CHILDREN) note(det,'… ещё '+(keys.length-MAX_CHILDREN)+' элементов (см. вид JSON)'); }
    det.addEventListener('toggle',function(){ if(det.open) build(); });
    if(open){ det.open=true; build(); }
    return det;
  }

  /* ---------- файлы ---------- */
  function loadFile(file){
    if(!file) return;
    S.fileName=file.name; S.enc=''; S.wb=null; $('sheetwrap').hidden=true; $('warn').dataset.size='';
    if(file.size>WARN_BYTES){ $('warn').dataset.size='1'; setMsg('warn','Файл больше 8 МБ ('+(file.size/1048576).toFixed(1)+' МБ) — обработка может занять время.'); }
    var r=new FileReader();
    r.onerror=function(){ setMsg('err','✖ Не удалось прочитать файл.'); };
    r.onload=function(){
      var buf=new Uint8Array(r.result);
      var zip=buf[0]===0x50&&buf[1]===0x4B, ole=buf[0]===0xD0&&buf[1]===0xCF&&buf[2]===0x11&&buf[3]===0xE0;
      if(EXCEL_EXT.test(file.name)||zip||ole||$('intype').value==='excel'){
        try{ S.wb=XLSX.read(buf,{type:'array',cellDates:true}); }
        catch(e){ setMsg('err','✖ Не удалось прочитать Excel-файл: '+e.message); return; }
        var sel=$('sheet'); sel.innerHTML='';
        S.wb.SheetNames.forEach(function(n){ var o=document.createElement('option'); o.value=o.textContent=n; sel.appendChild(o); });
        $('sheetwrap').hidden=S.wb.SheetNames.length<2;
        $('input').value=''; $('input').placeholder='Загружен Excel-файл «'+file.name+'». Введите текст, чтобы работать с текстом вместо файла.';
        $('intype').value='auto'; parse(); return;
      }
      // текст: UTF-8, при «битых» символах пробуем Windows-1251
      var text=new TextDecoder('utf-8').decode(buf); S.enc='UTF-8';
      if(text.indexOf('\uFFFD')>=0){ try{ text=new TextDecoder('windows-1251').decode(buf); S.enc='Windows-1251'; }catch(e){} }
      $('input').value=text.replace(/^\uFEFF/,'');
      if(/\.tsv$/i.test(file.name)) $('delim').value='tab';
      parse();
    };
    r.readAsArrayBuffer(file);
  }
  $('file').addEventListener('change',function(){ loadFile(this.files[0]); this.value=''; });
  // drag & drop на всю страницу с подсветкой зоны
  var zone=$('drop'), depthCnt=0;
  ['dragenter','dragover'].forEach(function(ev){ document.addEventListener(ev,function(e){ e.preventDefault(); if(ev==='dragenter') depthCnt++; zone.classList.add('dragover'); }); });
  document.addEventListener('dragleave',function(){ if(--depthCnt<=0){ depthCnt=0; zone.classList.remove('dragover'); } });
  document.addEventListener('drop',function(e){ e.preventDefault(); depthCnt=0; zone.classList.remove('dragover'); if(e.dataTransfer&&e.dataTransfer.files.length) loadFile(e.dataTransfer.files[0]); });

  /* ---------- действия ---------- */
  function textFor(kind){ return kind==='json'?JSON.stringify(S.data,null,2): kind==='tsv'?DL.toCSV(DL.toAOA(S.data),'\t'):DL.toCSV(DL.toAOA(S.data),outDelim()); }
  function download(name,blob){ var a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1000); }
  function need(){ if(S.data===undefined){ toast('Нет данных'); return false; } return true; }
  $('copy').addEventListener('click',function(){ if(!need()) return; copyText(textFor(S.view==='csv'?'csv':S.view==='table'?'tsv':'json')); });
  $('dlcsv').addEventListener('click',function(){ if(need()) download('converted_'+stamp()+'.csv',new Blob(['\uFEFF'+textFor('csv')],{type:'text/csv;charset=utf-8'})); });
  $('dljson').addEventListener('click',function(){ if(need()) download('converted_'+stamp()+'.json',new Blob([textFor('json')],{type:'application/json'})); });
  $('dlxlsx').addEventListener('click',function(){ if(!need()) return;
    var aoa=DL.toAOA(S.data).map(function(r){return r.map(function(v){return v!==null&&typeof v==='object'?JSON.stringify(v):v;});});
    var wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(aoa),'Данные'); XLSX.writeFile(wb,'converted_'+stamp()+'.xlsx'); });
  $('clear').addEventListener('click',function(){ $('input').value=''; S.wb=null; S.fileName=''; S.enc=''; $('sheetwrap').hidden=true; $('warn').dataset.size=''; S.userView=false; parse(); });
  document.querySelectorAll('[data-view]').forEach(function(b){ b.addEventListener('click',function(){ S.view=b.dataset.view; S.userView=true; render(); }); });
  var t; $('input').addEventListener('input',function(){ if(S.wb){ S.wb=null; $('sheetwrap').hidden=true; } S.fileName=''; S.enc=''; $('warn').dataset.size=''; clearTimeout(t); t=setTimeout(parse,250); });
  ['intype','delim','headers','types','nest','sheet'].forEach(function(id){ $(id).addEventListener('change',parse); });
  $('outdelim').addEventListener('change',render);
  // пример для старта
  $('input').value='id;name;city;tags.0;tags.1\n1;Анна;Москва;admin;dev\n2;"Иванов, Пётр";"Санкт-\nПетербург";dev;\n3;Ольга;Казань;;';
  parse();
})();
