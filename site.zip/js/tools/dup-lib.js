/* Поиск дубликатов (без DOM, тестируется в Node). Map-based, O(n). */
(function(root){
  'use strict';
  var SEPS={newline:/\r\n|\r|\n/, comma:/,/, space:/[ \u00A0]+/, semicolon:/;/, tab:/\t/, any:/[\s,;]+/};
  /** Разбить текст на значения. sep: auto|newline|comma|space|semicolon|tab|any */
  function split(text,sep){
    var re;
    if(sep==='auto'){
      if(/[\r\n]/.test(text)) re=/\r\n|\r|\n|\t/;          // копия из Excel: строки и ячейки
      else if(/[,;]/.test(text)) re=/[,;]/;
      else re=/[ \u00A0\t]+/;
    } else re=SEPS[sep]||SEPS.any;
    return text.split(re);
  }
  /** Подсчёт: возвращает {items:[{value,count,first}], total} в порядке первого появления */
  function count(values,opt){
    opt=opt||{};
    var map=new Map(), items=[], total=0;
    for(var i=0;i<values.length;i++){
      var v=values[i]; if(opt.trim) v=v.trim();
      if(opt.ignoreEmpty && v==='') continue;
      total++;
      var k=opt.ignoreCase ? v.toLocaleLowerCase('ru') : v, it=map.get(k);
      if(it) it.count++; else { it={value:v,count:1,first:items.length}; map.set(k,it); items.push(it); }
    }
    return {items:items,total:total};
  }
  /** mode: dups|unique|single; sort: orig|az|count */
  function select(res,mode,sort){
    var out = mode==='dups' ? res.items.filter(function(x){return x.count>1;})
            : mode==='single' ? res.items.filter(function(x){return x.count===1;}) : res.items.slice();
    if(sort==='az'){ var coll=new Intl.Collator('ru',{numeric:true,sensitivity:'base'}); out.sort(function(a,b){return coll.compare(a.value,b.value)||a.first-b.first;}); }
    else if(sort==='count') out.sort(function(a,b){return b.count-a.count||a.first-b.first;});
    return out;
  }
  function stats(res){
    var dupVals=0, extra=0; res.items.forEach(function(x){ if(x.count>1){ dupVals++; extra+=x.count-1; } });
    return {total:res.total, unique:res.items.length, dupValues:dupVals, extraCopies:extra, singles:res.items.length-dupVals};
  }
  /** Текст результата; withCounts при разделителе «перевод строки» — через Tab (вставляется в Excel двумя колонками) */
  function format(items,sep,withCounts){
    var j={newline:'\n',comma:', ',semicolon:';',tab:'\t',space:' '}[sep]||'\n';
    return items.map(function(x){ return withCounts ? (sep==='newline'? x.value+'\t'+x.count : x.value+' ('+x.count+')') : x.value; }).join(j);
  }
  var lib={split:split,count:count,select:select,stats:stats,format:format};
  if(typeof module!=='undefined'&&module.exports) module.exports=lib; else root.DupLib=lib;
})(this);
