/* Unix timestamp: текущее время и timestamp → дата */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var tz=Intl.DateTimeFormat().resolvedOptions().timeZone||'локальный';
  var off=-new Date().getTimezoneOffset(), offStr='UTC'+(off>=0?'+':'-')+('0'+Math.floor(Math.abs(off)/60)).slice(-2)+':'+('0'+Math.abs(off)%60).slice(-2);
  $('tz').textContent=tz+' ('+offStr+')';
  function pad(n){return ('0'+n).slice(-2);}
  function fromTs(){
    var v=$('ts').value.trim();
    if(!/^-?\d+(\.\d+)?$/.test(v)){ $('unit').textContent=''; $('local').textContent=$('utc').textContent=$('iso').textContent=v?'Некорректное число':'—'; return; }
    var n=+v, ms=Math.abs(n)>=1e11; // авто: ≥1e11 считаем миллисекундами
    var d=new Date(ms?n:n*1000);
    if(isNaN(d)){ $('local').textContent='Вне диапазона'; return; }
    $('unit').textContent=ms?'Распознано как миллисекунды':'Распознано как секунды';
    $('local').textContent=d.toLocaleString('ru-RU',{dateStyle:'full',timeStyle:'medium'});
    $('utc').textContent=d.toLocaleString('ru-RU',{dateStyle:'full',timeStyle:'medium',timeZone:'UTC'})+' UTC';
    $('iso').textContent=d.toISOString();
  }
  function tick(){ var t=Date.now(); $('nows').textContent=Math.floor(t/1000); $('nowms').textContent=t; }
  $('ts').addEventListener('input',fromTs);
  $('now').addEventListener('click',function(){ $('ts').value=Math.floor(Date.now()/1000); fromTs(); });
  document.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){copyText($(b.dataset.copy).textContent);});});
  setInterval(tick,1000); tick();
  $('ts').value=Math.floor(Date.now()/1000); fromTs();
})();
