/* Хеш-генератор: MD5 (всегда чистый JS), SHA-1/SHA-256 через crypto.subtle если доступен (secure context), иначе fallback на HashLib */
(function(){
  'use strict';
  var input=document.getElementById('text');
  var useSubtle = !!(window.crypto && crypto.subtle && window.isSecureContext);
  document.getElementById('mode').textContent = useSubtle ? 'Web Crypto API (crypto.subtle)' : 'чистый JS (crypto.subtle недоступен, напр. file://)';
  function toHex(buf){ return Array.prototype.map.call(new Uint8Array(buf),function(b){return ('0'+b.toString(16)).slice(-2);}).join(''); }
  function digest(alg, bytes){
    if(useSubtle) return crypto.subtle.digest(alg, bytes).then(toHex).catch(function(){ return alg==='SHA-1'?HashLib.sha1(bytes):HashLib.sha256(bytes); });
    return Promise.resolve(alg==='SHA-1'?HashLib.sha1(bytes):HashLib.sha256(bytes));
  }
  function update(){
    var bytes=new TextEncoder().encode(input.value);
    document.getElementById('md5').textContent=HashLib.md5(bytes);
    digest('SHA-1',bytes).then(function(h){document.getElementById('sha1').textContent=h;});
    digest('SHA-256',bytes).then(function(h){document.getElementById('sha256').textContent=h;});
  }
  input.addEventListener('input',update);
  document.querySelectorAll('[data-copy]').forEach(function(b){ b.addEventListener('click',function(){ copyText(document.getElementById(b.dataset.copy).textContent); }); });
  update();
})();
