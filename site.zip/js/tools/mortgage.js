/* Ипотечный калькулятор: аннуитет + досрочные погашения (логика в mortgage-calc.js) */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var rub=function(v){return fmt(v)+' ₽';};
  function term(m){ var y=Math.floor(m/12), r=m%12, a=[]; if(y) a.push(y+' г.'); if(r) a.push(r+' мес.'); return m+' мес. ('+a.join(' ')+')'; }
  /* ---- строки досрочных погашений ---- */
  function addRow(a,m,t){
    var tr=document.createElement('tr');
    tr.innerHTML='<td><input type="number" class="ex-a" min="0" step="10000" value="'+(a||100000)+'"></td>'+
      '<td><input type="number" class="ex-m" min="1" step="1" value="'+(m||12)+'"></td>'+
      '<td><select class="ex-t"><option value="once">Разово</option><option value="monthly">Ежемесячно с месяца N</option><option value="yearly">Ежегодно с месяца N</option></select></td>'+
      '<td><button class="secondary ex-del" title="Удалить" aria-label="Удалить">✕</button></td>';
    tr.querySelector('.ex-t').value=t||'once';
    tr.querySelector('.ex-del').addEventListener('click',function(){tr.remove();calc();});
    tr.querySelectorAll('input,select').forEach(function(el){el.addEventListener('input',calc);});
    $('extras').appendChild(tr);
  }
  function extras(){ return Array.prototype.map.call($('extras').rows,function(tr){
    return {amount:+tr.querySelector('.ex-a').value,month:+tr.querySelector('.ex-m').value,type:tr.querySelector('.ex-t').value}; }); }
  function calc(){
    var P=+$('amount').value, rate=+$('rate').value, n=Math.round(+$('term').value*12);
    if(!(P>0&&n>0&&rate>=0)){ $('res').hidden=true; return; }
    var C=MortgageCalc.compare(P,rate,n,extras()), mode=$('mode').value, S=C[mode];
    $('pay').textContent=rub(S.firstPay); $('over').textContent=rub(S.interest); $('total').textContent=rub(S.total); $('months').textContent=term(S.months);
    // таблица сравнения
    var cols=[['base','Без досрочки'],['term','Уменьшение срока'],['payment','Уменьшение платежа']];
    var best=C.term.saved>C.payment.saved+0.005?'term':C.payment.saved>C.term.saved+0.005?'payment':'';
    var rowsDef=[['Платёж (начальный)',function(s){return rub(s.firstPay);}],['Платёж после досрочки',function(s){return rub(s.payAfter);}],
      ['Фактический срок',function(s){return term(s.months);}],['Переплата (проценты)',function(s){return rub(s.interest);}],
      ['Всего выплачено',function(s){return rub(s.total);}],['Экономия процентов',function(s){return rub(s.saved)+' ('+fmt(s.savedPct,1)+'%)';}],
      ['Сокращение срока',function(s){return s.monthsSaved+' мес.';}]];
    $('cmp').innerHTML='<thead><tr><th style="text-align:left">Показатель</th>'+cols.map(function(c){return '<th class="'+(c[0]===best?'best':'')+'">'+c[1]+(c[0]===best?' ★':'')+'</th>';}).join('')+'</tr></thead><tbody>'+
      rowsDef.map(function(r){return '<tr><td style="text-align:left">'+r[0]+'</td>'+cols.map(function(c){return '<td class="'+(c[0]===best?'best':'')+'">'+r[1](C[c[0]])+'</td>';}).join('')+'</tr>';}).join('')+'</tbody>';
    $('verdict').textContent= C.term.extra>0 ? (best==='term'?'Выгоднее уменьшать срок: экономия на '+rub(C.term.saved-C.payment.saved)+' больше.':best==='payment'?'Выгоднее уменьшать платёж: экономия на '+rub(C.payment.saved-C.term.saved)+' больше.':'Оба варианта дают одинаковую экономию.') : 'Добавьте досрочные погашения, чтобы сравнить варианты.';
    // график платежей выбранного режима
    $('tbody').innerHTML=S.rows.map(function(r){return '<tr><td>'+r.i+'</td><td>'+fmt(r.pay)+'</td><td>'+fmt(r.princ)+'</td><td>'+fmt(r.int)+'</td><td>'+(r.extra?'<b>'+fmt(r.extra)+'</b>':'—')+'</td><td>'+fmt(r.bal)+'</td></tr>';}).join('');
    $('res').hidden=false; draw(S.rows,P,n);
  }
  /** График: столбики тело/проценты/досрочка + линия остатка; ось X — исходный срок, чтобы было видно сокращение */
  function draw(rows,P,n){
    var c=$('chart'), ctx=c.getContext('2d'), W=c.width, H=c.height, pad=30, bw=(W-2*pad)/n, h=(H-2*pad)*0.5;
    var maxPay=Math.max.apply(null,rows.map(function(r){return r.pay;}));
    ctx.clearRect(0,0,W,H);
    rows.forEach(function(r,i){
      var x=pad+i*bw, hp=r.princ/maxPay*h, hi=r.int/maxPay*h, w=Math.max(bw,1);
      ctx.fillStyle='#a5b4fc'; ctx.fillRect(x,H-pad-hp,w,hp);
      ctx.fillStyle='#fca5a5'; ctx.fillRect(x,H-pad-hp-hi,w,hi);
      if(r.extra){ ctx.fillStyle='#16a34a'; ctx.fillRect(x,pad,Math.max(w,2),H-2*pad); }
    });
    ctx.strokeStyle='#4f46e5'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(pad,pad);
    rows.forEach(function(r,i){ ctx.lineTo(pad+(i+1)*bw,H-pad-r.bal/P*(H-2*pad)); }); ctx.stroke();
    ctx.fillStyle='#374151'; ctx.font='12px sans-serif';
    ctx.fillText('— остаток долга   ■ тело (синий)   ■ проценты (красный)   | досрочное погашение (зелёный)',pad,16);
  }
  ['amount','rate','term','mode'].forEach(function(id){$(id).addEventListener('input',calc);});
  $('addex').addEventListener('click',function(){addRow();calc();});
  addRow(500000,12,'once');
  calc();
})();
