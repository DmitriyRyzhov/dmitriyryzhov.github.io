/* Даты: возраст, разница, рабочие дни, обратный отсчёт (без DOM, тестируется в Node).
   Даты — строки 'YYYY-MM-DD', внутри — номер дня (UTC), чтобы не зависеть от часовых поясов. */
(function(root){
  'use strict';
  var PC=(typeof module!=='undefined'&&module.exports)?require('./prodcal-data.js'):root.ProdCalData;
  var DAY=86400000;
  function parse(s){var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s||'').trim()); if(!m) return NaN; var y=+m[1],mo=+m[2],d=+m[3],t=Date.UTC(y,mo-1,d), x=new Date(t);
    if(x.getUTCMonth()!==mo-1||x.getUTCDate()!==d) return NaN; return t/DAY;}
  function iso(n){return new Date(n*DAY).toISOString().slice(0,10);}
  function ymd(n){var x=new Date(n*DAY);return [x.getUTCFullYear(),x.getUTCMonth()+1,x.getUTCDate()];}
  function dim(y,m){return new Date(Date.UTC(y,m,0)).getUTCDate();}
  function wd(n){return (new Date(n*DAY).getUTCDay()+6)%7;} // 0 = пн
  function todayLocal(){var d=new Date();return Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/DAY;}
  var WD=['понедельник','вторник','среда','четверг','пятница','суббота','воскресенье'];
  // разница y/m/d между a<=b (календарная)
  function addMonths(n,k){var p=ymd(n),t=p[0]*12+(p[1]-1)+k,y=Math.floor(t/12),m=t%12+1;return Date.UTC(y,m-1,Math.min(p[2],dim(y,m)))/DAY;}
  function ymdDiff(a,b){var A=ymd(a),B=ymd(b),tm=(B[0]-A[0])*12+(B[1]-A[1]); if(addMonths(a,tm)>b) tm--; return {y:Math.floor(tm/12),m:tm%12,d:b-addMonths(a,tm)};}
  // дата рождения в году y (29 февраля → 28 февраля в невисокосный год)
  function bdayIn(y,mo,d){ if(mo===2&&d===29&&dim(y,2)===28) d=28; return Date.UTC(y,mo-1,d)/DAY; }
  var ZOD=[['Козерог',1,19],['Водолей',2,18],['Рыбы',3,20],['Овен',4,19],['Телец',5,20],['Близнецы',6,20],['Рак',7,22],['Лев',8,22],['Дева',9,22],['Весы',10,22],['Скорпион',11,21],['Стрелец',12,21],['Козерог',12,31]];
  function zodiac(mo,d){for(var i=0;i<ZOD.length;i++){if(mo<ZOD[i][1]||(mo===ZOD[i][1]&&d<=ZOD[i][2])) return ZOD[i][0];} return 'Козерог';}
  function age(dob,on){
    var a=parse(dob), b=on?parse(on):todayLocal(); if(isNaN(a)||isNaN(b)) return {ok:false,error:'Введите корректную дату.'};
    if(b<a) return {ok:false,error:'Дата рождения позже расчётной даты.'};
    var D=ymd(a), r=ymdDiff(a,b), days=b-a, B=ymd(b), nb=bdayIn(B[0],D[1],D[2]); if(nb<b) nb=bdayIn(B[0]+1,D[1],D[2]);
    var nextAge=ymd(nb)[0]-D[0];
    return {ok:true,years:r.y,months:r.m,days:r.d,totalMonths:r.y*12+r.m,totalWeeks:Math.floor(days/7),weeksRem:days%7,totalDays:days,totalHours:days*24,
      nextBirthday:iso(nb),daysToBirthday:nb-b,nextAge:nextAge,isBirthday:nb===b,weekday:WD[wd(a)],zodiac:zodiac(D[1],D[2]),leap:D[1]===2&&D[2]===29};
  }
  // производственный календарь
  var cache={};
  function yearInfo(y){ if(cache[y]) return cache[y]; var d=PC.DATA[y], s={off:{},work:{},short:{},hol:{},known:!!d};
    var hol=d?d.holidays:['01-01','01-02','01-03','01-04','01-05','01-06','01-07','01-08','02-23','03-08','05-01','05-09','06-12','11-04'];
    hol.forEach(function(k){s.hol[k]=1;});
    if(d){d.off.forEach(function(k){s.off[k]=1;});d.work.forEach(function(k){s.work[k]=1;});d.short.forEach(function(k){s.short[k]=1;});}
    return cache[y]=s; }
  function dayType(n){ // 'work' | 'short' | 'weekend' | 'holiday'
    var p=ymd(n), k=(p[1]<10?'0':'')+p[1]+'-'+(p[2]<10?'0':'')+p[2], I=yearInfo(p[0]);
    if(I.work[k]) return I.short[k]?'short':'work';
    if(I.hol[k]) return 'holiday'; if(I.off[k]) return 'weekend'; if(wd(n)>=5) return 'weekend';
    return I.short[k]?'short':'work'; }
  function isWork(n){var t=dayType(n);return t==='work'||t==='short';}
  function workStats(a,b){ // включительно
    var w=0,s=0,off=0,hol=0,unknown={}; for(var n=a;n<=b;n++){var t=dayType(n); if(t==='work')w++; else if(t==='short'){w++;s++;} else {off++; if(t==='holiday')hol++;} var y=ymd(n)[0]; if(!PC.DATA[y]) unknown[y]=1;}
    var r=function(x){return Math.round(x*10)/10;};
    return {calendar:b-a+1,work:w,short:s,off:off,holidays:hol,h40:r(w*8-s),h36:r(w*7.2-s),h24:r(w*4.8-s),unknownYears:Object.keys(unknown).map(Number)}; }
  function addWorkdays(start,n){ // n>0 вперёд, n<0 назад; старт не считается
    var d=start, step=n<0?-1:1, k=Math.abs(n); while(k>0){d+=step; if(isWork(d)) k--;} return d; }
  function between(a,b,incl){
    var A=parse(a),B=parse(b); if(isNaN(A)||isNaN(B)) return {ok:false,error:'Введите обе даты.'};
    var sign=1; if(B<A){var t=A;A=B;B=t;sign=-1;}
    var days=B-A+(incl?1:0), r=ymdDiff(A,B+(incl?1:0)), end=incl?B:B-1, ws=end<A?{work:0,off:0}:workStats(A,end);
    return {ok:true,sign:sign,days:days,weeks:Math.floor(days/7),weekDays:days%7,y:r.y,m:r.m,d:r.d,totalMonths:r.y*12+r.m,years:days/365.2425,work:ws.work,off:ws.off};
  }
  function addDays(a,n){var A=parse(a);if(isNaN(A))return null; var r=A+Math.trunc(+n||0); return {date:iso(r),weekday:WD[wd(r)]};}
  function countdown(nowMs,targetMs){var diff=targetMs-nowMs, past=diff<0, x=Math.abs(diff), s=Math.floor(x/1000);
    return {past:past,ms:diff,days:Math.floor(s/86400),hours:Math.floor(s%86400/3600),minutes:Math.floor(s%3600/60),seconds:s%60};}
  var api={parse:parse,iso:iso,ymd:ymd,wd:wd,WD:WD,todayLocal:todayLocal,age:age,zodiac:zodiac,dayType:dayType,isWork:isWork,workStats:workStats,addWorkdays:addWorkdays,between:between,addDays:addDays,countdown:countdown,yearInfo:yearInfo,PC:PC};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.DateLib=api;
})(this);
