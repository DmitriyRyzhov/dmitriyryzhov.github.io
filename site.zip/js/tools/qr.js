/* Генератор QR-кодов (движок: js/vendor/qrcode.js, MIT, Kazuhiko Arase) */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  qrcode.stringToBytes=qrcode.stringToBytesFuncs['UTF-8']; // поддержка кириллицы
  /** Экранирование спецсимволов для формата WIFI: */
  function wifiEsc(s){ return s.replace(/([\\;,:"])/g,'\\$1'); }
  /** Экранирование для vCard */
  function vEsc(s){ return s.replace(/([\\;,])/g,'\\$1').replace(/\n/g,'\\n'); }
  /** Собрать строку для кодирования по выбранному режиму */
  function payload(){
    switch($('mode').value){
      case 'url': var u=$('url').value.trim(); return u&&!/^[a-z][a-z0-9+.-]*:/i.test(u)?'https://'+u:u;
      case 'wifi':
        var t=$('wsec').value, s='WIFI:T:'+t+';S:'+wifiEsc($('ssid').value)+';';
        if(t!=='nopass') s+='P:'+wifiEsc($('wpass').value)+';';
        if($('whidden').checked) s+='H:true;';
        return s+';';
      case 'vcard':
        var L=['BEGIN:VCARD','VERSION:3.0'], n=$('vname').value.trim();
        if(n){ var p=n.split(/\s+/); L.push('N:'+vEsc(p.slice(1).join(' '))+';'+vEsc(p[0])+';;;'); L.push('FN:'+vEsc(n)); }
        if($('vorg').value) L.push('ORG:'+vEsc($('vorg').value));
        if($('vtel').value) L.push('TEL;TYPE=CELL:'+vEsc($('vtel').value));
        if($('vmail').value) L.push('EMAIL:'+vEsc($('vmail').value));
        L.push('END:VCARD'); return L.join('\r\n');
      default: return $('text').value;
    }
  }
  function render(){
    document.querySelectorAll('[data-mode]').forEach(function(f){ f.hidden=f.dataset.mode!==$('mode').value; });
    var data=payload(), c=$('canvas'), ctx=c.getContext('2d'), size=+$('size').value;
    $('raw').textContent=data;
    c.width=c.height=size; ctx.fillStyle='#fff'; ctx.fillRect(0,0,size,size);
    if(!data){ $('err').textContent='Введите данные'; return; }
    try{
      var q=qrcode(0,$('ecl').value); q.addData(data,'Byte'); q.make();
      var n=q.getModuleCount(), quiet=4, cell=size/(n+quiet*2);
      ctx.fillStyle='#000';
      for(var r=0;r<n;r++) for(var k=0;k<n;k++) if(q.isDark(r,k))
        ctx.fillRect(Math.floor((k+quiet)*cell),Math.floor((r+quiet)*cell),Math.ceil(cell),Math.ceil(cell));
      $('err').textContent='';
    }catch(e){ $('err').textContent='Слишком много данных для QR-кода'; }
  }
  document.querySelectorAll('input,select,textarea').forEach(function(el){el.addEventListener('input',render);});
  $('dl').addEventListener('click',function(){ var a=document.createElement('a'); a.download='qrcode.png'; a.href=$('canvas').toDataURL('image/png'); a.click(); });
  render();
})();
