/* Сколько дней между датами (UI); расчёт в date-lib.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, L=DateLib, t=L.iso(L.todayLocal());
  function n(x,d){return Number(x).toLocaleString('ru-RU',{maximumFractionDigits:d||0});}
  function pl(x,a,b,c){x=Math.abs(x)%100;var y=x%10;return x>10&&x<20?c:y===1?a:y>=2&&y<=4?b:c;}
  $('a').value=t; $('b').value=(+t.slice(0,4)+1)+'-01-01'; $('base').value=t;
  function calc(){
    var r=L.between($('a').value,$('b').value,$('incl').checked);
    if(!r.ok){$('out').hidden=true;return;} $('out').hidden=false;
    $('days').textContent=n(r.days)+' '+pl(r.days,'день','дня','дней')+(r.sign<0?' (вторая дата раньше первой)':'');
    $('wk').textContent=n(r.weeks)+' нед. '+r.weekDays+' дн.'; $('mo').textContent=n(r.totalMonths)+' мес. '+r.d+' дн.'+(r.y?' ('+r.y+' '+pl(r.y,'год','года','лет')+' '+r.m+' мес. '+r.d+' дн.)':'');
    $('yr').textContent=n(r.years,2); $('wdays').textContent=n(r.work); $('off').textContent=n(r.off);
  }
  function add(){var v=Math.trunc(+$('n').value||0)*($('dir').value==='-'?-1:1),r=L.addDays($('base').value,v);
    $('addres').textContent=r?r.date.split('-').reverse().join('.')+' — '+r.weekday:'Введите дату';}
  ['a','b','incl'].forEach(function(id){$(id).addEventListener('input',calc);$(id).addEventListener('change',calc);});
  ['base','n','dir'].forEach(function(id){$(id).addEventListener('input',add);$(id).addEventListener('change',add);});
  $('swap').addEventListener('click',function(){var x=$('a').value;$('a').value=$('b').value;$('b').value=x;calc();});
  calc(); add();
})();
