/* Сложные проценты помесячно (без DOM, тестируется в Node).
   P — начальная сумма, ratePct — % годовых, months — срок в месяцах (любое целое, вкл. неполные годы),
   k — капитализаций в год (12, 4, 2, 1), monthly — пополнение в конце каждого месяца.
   Проценты начисляются ежемесячно на текущий капитализированный остаток (простые внутри периода),
   причисляются в конце каждого периода капитализации и в конце срока (неполный период). */
(function(root){
  'use strict';
  function compound(P,ratePct,months,k,monthly,days){
    var r=ratePct/100/12, step=12/k, bal=P, pending=0, contrib=P, interest=0, rows=[];
    monthly=+monthly||0;
    for(var i=1;i<=months;i++){
      var int=bal*r; pending+=int; interest+=int;
      bal+=monthly; contrib+=monthly;               // пополнение в конце месяца — проценты с него со следующего месяца
      if(i%step===0||i===months){ bal+=pending; pending=0; }
      rows.push({month:i,balance:bal+pending});
    }
    days=Math.max(0,Math.floor(+days||0));
    if(days){ var di=bal*ratePct/100*days/365; bal+=di; interest+=di; rows.push({month:months+days/30,balance:bal}); } // остаток дней: простые проценты (год = 365 дн.), причисляются в конце срока
    return {final:bal,contrib:contrib,interest:interest,rows:rows};
  }
  var lib={compound:compound};
  if(typeof module!=='undefined'&&module.exports) module.exports=lib; else root.CompoundCalc=lib;
})(this);
