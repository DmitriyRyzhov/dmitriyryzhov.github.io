/* Дата (локальное время браузера) → Unix timestamp */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var tz=Intl.DateTimeFormat().resolvedOptions().timeZone||'локальный';
  var off=-new Date().getTimezoneOffset(), offStr='UTC'+(off>=0?'+':'-')+('0'+Math.floor(Math.abs(off)/60)).slice(-2)+':'+('0'+Math.abs(off)%60).slice(-2);
  $('tz').textContent=tz+' ('+offStr+')';
  function pad(n){return ('0'+n).slice(-2);}
  /** Значение для input[type=datetime-local] в локальном времени */
  function toLocalInput(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());}
  function fromDate(){
    var v=$('dt').value; if(!v){ $('dsec').textContent=$('dms').textContent=$('diso').textContent='—'; return; }
    var d=new Date(v); // строка без зоны = локальное время
    $('dsec').textContent=Math.floor(d.getTime()/1000); $('dms').textContent=d.getTime(); $('diso').textContent=d.toISOString();
  }
  $('dt').addEventListener('input',fromDate);
  $('now').addEventListener('click',function(){ $('dt').value=toLocalInput(new Date()); fromDate(); });
  document.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){copyText($(b.dataset.copy).textContent);});});
  $('dt').value=toLocalInput(new Date()); fromDate();
})();
