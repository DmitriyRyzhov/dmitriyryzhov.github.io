/* Налоговый калькулятор зарплаты, РФ, 2026 (без DOM, тестируется в Node).
   НДФЛ: прогрессивная шкала (ст. 224 НК РФ), считается нарастающим итогом с начала года.
   Страховые взносы: единый тариф (ст. 425, 427 НК РФ), предельная база 2 979 000 ₽ (ПП РФ № 1705),
   МРОТ 27 093 ₽ (ФЗ № 429-ФЗ). Взносы на травматизм — отдельно, без предельной базы. */
(function(root){
  'use strict';
  var Y=2026, BASE=2979000, MROT=27093;
  var NDFL=[[2400000,0.13],[5000000,0.15],[20000000,0.18],[50000000,0.20],[Infinity,0.22]];
  // тарифы работодателя: below — до базы, above — сверх базы, mspRate — ставка с превышения над 1,5 МРОТ в месяц
  var EMP={
    general:{name:'Общий тариф',below:0.30,above:0.151},
    msp:{name:'МСП из перечня (15% сверх 1,5 МРОТ)',below:0.30,above:0.151,mspRate:0.15},
    mspmfg:{name:'МСП обрабатывающее производство (7,6% сверх 1,5 МРОТ)',below:0.30,above:0.151,mspRate:0.076},
    it:{name:'Аккредитованная IT-компания',below:0.15,above:0.076}
  };
  function r2(x){return Math.round(x*100)/100;}
  function ndflCum(inc){ // НДФЛ с дохода нарастающим итогом
    var t=0,prev=0;
    for(var i=0;i<NDFL.length;i++){var lim=NDFL[i][0]; if(inc>prev) t+=(Math.min(inc,lim)-prev)*NDFL[i][1]; prev=lim;}
    return t;
  }
  function brackets(inc){
    var out=[],prev=0;
    for(var i=0;i<NDFL.length;i++){var lim=NDFL[i][0],part=Math.max(0,Math.min(inc,lim)-prev);
      out.push({from:prev,to:lim,rate:NDFL[i][1],base:part,tax:part*NDFL[i][1]}); prev=lim;}
    return out;
  }
  function rateAt(inc){for(var i=0;i<NDFL.length;i++) if(inc<=NDFL[i][0]) return NDFL[i][1]; return 0.22;}
  // взносы за месяц: cumPrev — облагаемая база с начала года до этого месяца
  function contribMonth(g,cumPrev,emp){
    var e=EMP[emp]||EMP.general;
    function split(amount,start){ // часть в пределах базы и сверх
      var inB=Math.max(0,Math.min(amount,BASE-start)); return [inB,amount-inB];
    }
    if(e.mspRate!=null){
      var lim=1.5*MROT, low=Math.min(g,lim), high=g-low, s=split(low,cumPrev);
      return s[0]*e.below+s[1]*e.above+high*e.mspRate;
    }
    var s2=split(g,cumPrev); return s2[0]*e.below+s2[1]*e.above;
  }
  function calc(grossMonthly,opt){
    opt=opt||{}; var emp=opt.employer||'general', inj=(opt.injury==null?0.2:+opt.injury)/100;
    var g=Math.max(0,+grossMonthly||0), rows=[], cum=0, cumTax=0, cumC=0, cumI=0, kick=[];
    for(var m=1;m<=12;m++){
      var before=cum, rBefore=m===1?0.13:rateAt(before); cum+=g;
      var tc=ndflCum(cum), tax=tc-cumTax; cumTax=tc;
      var c=contribMonth(g,before,emp), inj_m=g*inj; cumC+=c; cumI+=inj_m;
      var top=rateAt(cum);
      if(g>0 && top>rBefore) kick.push({month:m,rate:top});
      rows.push({month:m,gross:g,cumGross:cum,ndfl:tax,net:g-tax,cumNdfl:tc,rate:top,contrib:c,injury:inj_m,maxRate:top});
    }
    var y=g*12, ndfl=cumTax, net=y-ndfl, emp_t=cumC+cumI, cost=y+emp_t, taxes=ndfl+emp_t;
    return {year:Y,grossMonthly:g,grossYear:y,ndfl:ndfl,effRate:y?ndfl/y:0,brackets:brackets(y),months:rows,kick:kick,
      net:net,netMonthlyAvg:net/12,contrib:cumC,injury:cumI,employerTaxes:emp_t,cost:cost,taxes:taxes,
      statePer100:cost?taxes/cost*100:0,employer:(EMP[emp]||EMP.general).name};
  }
  // обратный расчёт: по сумме «на руки» в месяц (среднемесячной за год) находим оклад до вычета
  function grossFromNet(netMonthly,opt){
    var target=Math.max(0,+netMonthly||0)*12; if(!target) return 0;
    var lo=0,hi=target/12/0.78+1;
    for(var i=0;i<100;i++){var mid=(lo+hi)/2; if(mid*12-ndflCum(mid*12)<target) lo=mid; else hi=mid;}
    return r2(hi);
  }
  var api={calc:calc,grossFromNet:grossFromNet,ndflCum:ndflCum,EMP:EMP,BASE:BASE,MROT:MROT,NDFL:NDFL,YEAR:Y};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.SalaryTax=api;
})(this);
