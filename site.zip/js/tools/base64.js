/* Base64 (UI); расчёт в base64-calc.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, bytes=null, mime='application/octet-stream', url=null;
  function enc(){ if(!$('live').checked&&this&&this.id==='plain') return; $('b64').value=B64.encode($('plain').value,$('urlsafe').checked); $('err').textContent=''; }
  function dec(){ if(!$('live').checked&&this&&this.id==='b64') return; showDecoded(); }
  function showDecoded(){
    var s=$('b64').value; $('err').textContent=''; $('prev').hidden=true; $('dl').hidden=true; bytes=null;
    if(!s.trim()){$('plain').value='';return;}
    try{var r=B64.decode(s);}catch(e){$('err').textContent='Ошибка: '+e.message;return;}
    bytes=r.bytes; var m=/^data:([^;,]+)/i.exec(s.trim()); mime=m?m[1]:B64.sniff(bytes);
    $('plain').value=r.binary?'':r.text; $('info').textContent='Декодировано байт: '+bytes.length+(r.binary?' · двоичные данные ('+mime+') — текстом не показать, скачайте файл':'')+'.';
    if(r.binary||/^image\//.test(mime)){ if(url) URL.revokeObjectURL(url); url=URL.createObjectURL(new Blob([bytes],{type:mime})); $('dl').hidden=false; $('dl').href=url; $('dl').download='decoded'+ext(mime);
      if(/^image\//.test(mime)){$('prev').src=url;$('prev').hidden=false;} }
  }
  function ext(m){return {'image/png':'.png','image/jpeg':'.jpg','image/gif':'.gif','image/webp':'.webp','image/svg+xml':'.svg','application/pdf':'.pdf','application/zip':'.zip'}[m]||'.bin';}
  $('plain').addEventListener('input',enc); $('b64').addEventListener('input',dec);
  $('urlsafe').addEventListener('change',function(){enc.call(null);});
  $('benc').addEventListener('click',function(){enc.call(null);}); $('bdec').addEventListener('click',function(){showDecoded();});
  $('cp1').addEventListener('click',function(){if($('plain').value) copyText($('plain').value);});
  $('cp2').addEventListener('click',function(){if($('b64').value) copyText($('b64').value);});
  $('file').addEventListener('change',function(){var f=this.files[0]; if(!f) return; if(f.size>20*1024*1024){$('ferr').textContent='Файл больше 20 МБ — слишком большой для браузера.';return;}
    var rd=new FileReader(); rd.onload=function(){var b=new Uint8Array(rd.result),s=B64.fromBytes(b,false),t=f.type||'application/octet-stream';
      $('fout').value=s; $('furi').value='data:'+t+';base64,'+s; $('finfo').textContent=f.name+' · '+b.length.toLocaleString('ru-RU')+' байт → '+s.length.toLocaleString('ru-RU')+' символов Base64'; $('ferr').textContent='';}; rd.readAsArrayBuffer(f);});
  $('cp3').addEventListener('click',function(){if($('fout').value) copyText($('fout').value);});
  $('cp4').addEventListener('click',function(){if($('furi').value) copyText($('furi').value);});
  $('plain').value='Привет, Cogle! 🐰'; enc.call(null);
})();
