/* Конвертер регистра */
(function(){
  'use strict';
  var t=document.getElementById('text');
  function words(s){ return s.replace(/([a-zа-яё0-9])([A-ZА-ЯЁ])/g,'$1 $2').split(/[^A-Za-zА-Яа-яЁё0-9]+/).filter(Boolean); }
  var ops={
    upper:function(s){return s.toUpperCase();},
    lower:function(s){return s.toLowerCase();},
    title:function(s){return s.toLowerCase().replace(/(^|[\s\-"'(«])([^\s])/g,function(_,a,b){return a+b.toUpperCase();});},
    camel:function(s){return words(s).map(function(w,i){w=w.toLowerCase();return i?w.charAt(0).toUpperCase()+w.slice(1):w;}).join('');},
    snake:function(s){return words(s).map(function(w){return w.toLowerCase();}).join('_');}
  };
  document.querySelectorAll('[data-op]').forEach(function(b){ b.addEventListener('click',function(){ t.value=ops[b.dataset.op](t.value); }); });
  document.getElementById('copy').addEventListener('click',function(){copyText(t.value);});
})();
