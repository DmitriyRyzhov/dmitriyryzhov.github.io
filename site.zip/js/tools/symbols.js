/* Специальные символы. Чтобы добавить блок — допишите объект в массив BLOCKS: {title, items:[[символ, 'название'], ...]} */
(function(){
  'use strict';
  var BLOCKS=[
    {title:'Стрелки', items:[['←','Стрелка влево'],['→','Стрелка вправо'],['↑','Стрелка вверх'],['↓','Стрелка вниз'],['↔','Стрелка влево-вправо'],['↕','Стрелка вверх-вниз'],
      ['⬅','Жирная стрелка влево'],['➡','Жирная стрелка вправо'],['⬆','Жирная стрелка вверх'],['⬇','Жирная стрелка вниз'],['◀','Треугольник влево'],['▶','Треугольник вправо'],
      ['▲','Треугольник вверх'],['▼','Треугольник вниз'],['➔','Стрелка вправо (широкая)'],['➜','Стрелка вправо (скруглённая)'],['➞','Стрелка вправо (острая)'],['↩','Стрелка возврата влево'],['↪','Стрелка возврата вправо']]},
    {title:'Статусы и отметки', items:[['✅','Зелёная галочка'],['❌','Красный крестик'],['⚠️','Предупреждение'],['ℹ️','Информация'],['✓','Галочка'],['✗','Крестик'],
      ['☑','Отмеченный флажок'],['☐','Пустой флажок'],['☒','Флажок с крестиком'],['⭐','Звезда (эмодзи)'],['★','Закрашенная звезда'],['☆','Контурная звезда']]},
    {title:'Математические', items:[['±','Плюс-минус'],['×','Умножение'],['÷','Деление'],['≈','Приблизительно равно'],['≠','Не равно'],['≤','Меньше или равно'],
      ['≥','Больше или равно'],['∞','Бесконечность'],['√','Квадратный корень'],['°','Градус'],['π','Пи'],['∆','Дельта (приращение)']]},
    {title:'Типографские', items:[['—','Длинное тире'],['–','Короткое тире'],['«','Открывающая кавычка-ёлочка'],['»','Закрывающая кавычка-ёлочка'],['“','Открывающая английская кавычка'],['”','Закрывающая английская кавычка'],
      ['…','Многоточие'],['•','Маркер списка'],['·','Точка по центру'],['©','Знак авторского права'],['®','Зарегистрированный товарный знак'],['™','Товарный знак']]},
    {title:'Валюты', items:[['$','Доллар'],['€','Евро'],['£','Фунт стерлингов'],['¥','Иена / юань'],['₽','Рубль'],['₴','Гривна'],['₸','Тенге']]},
    {title:'Прочие полезные', items:[['☎','Телефон'],['✉','Конверт'],['№','Номер'],['§','Параграф'],['⌘','Command (Mac)'],['⌥','Option (Mac)'],['↵','Enter / перевод строки']]}
  ];
  var out=document.getElementById('out'), box=document.getElementById('blocks');
  /** Скопировать только символ (через common.js: clipboard API или fallback для file://) без потери фокуса/выделения в поле */
  function copySymbol(ch){
    if(navigator.clipboard && window.isSecureContext){ navigator.clipboard.writeText(ch).then(function(){toast('Скопировано: '+ch);},function(){fallback(ch);}); }
    else fallback(ch);
  }
  function fallback(ch){ var ta=document.createElement('textarea'); ta.value=ch; ta.setAttribute('readonly',''); ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); toast('Скопировано: '+ch); }catch(e){ toast('Не удалось скопировать'); } ta.remove(); }
  BLOCKS.forEach(function(b){
    var sec=document.createElement('section'); sec.className='sym-block';
    var h=document.createElement('h2'); h.textContent=b.title; sec.appendChild(h);
    var grid=document.createElement('div'); grid.className='sym-grid';
    b.items.forEach(function(it){
      var btn=document.createElement('button'); btn.type='button'; btn.className='sym'; // U+FE0E — текстовое (не эмодзи) начертание только для показа; копируется исходный символ
      btn.textContent=/[\uFE0F]|[\u2705\u274C\u2B50]/.test(it[0]) ? it[0] : it[0]+'\uFE0E';
      btn.title=it[1]; btn.setAttribute('aria-label',it[1]+' ('+it[0]+')'); btn.dataset.tip=it[1];
      btn.addEventListener('click',function(){ out.value+=it[0]; copySymbol(it[0]); });
      grid.appendChild(btn);
    });
    sec.appendChild(grid); box.appendChild(sec);
  });
  document.getElementById('clear').addEventListener('click',function(){ out.value=''; out.focus(); });
  document.getElementById('copyall').addEventListener('click',function(){ if(out.value) copyText(out.value); else toast('Поле пустое'); });
})();
