/* Конвертеры единиц: вес, длина, температура (без DOM, тестируется в Node). */
(function(root){
  'use strict';
  var WEIGHT={unit:'г',list:[['mg','Миллиграмм','мг',0.001],['g','Грамм','г',1],['kg','Килограмм','кг',1000],['c','Центнер','ц',100000],['t','Тонна','т',1e6],
    ['ct','Карат','кар',0.2],['oz','Унция','oz',28.349523125],['ozt','Тройская унция','oz t',31.1034768],['lb','Фунт','lb',453.59237],['st','Стоун','st',6350.29318],
    ['pud','Пуд','пуд',16380.496],['rlb','Фунт русский','фунт',409.51241],['zol','Золотник','зол.',4.26575417]]};
  var LENGTH={unit:'м',list:[['mm','Миллиметр','мм',0.001],['cm','Сантиметр','см',0.01],['dm','Дециметр','дм',0.1],['m','Метр','м',1],['km','Километр','км',1000],
    ['in','Дюйм','in',0.0254],['ft','Фут','ft',0.3048],['yd','Ярд','yd',0.9144],['mi','Миля','mi',1609.344],['nmi','Морская миля','nmi',1852],
    ['versta','Верста','вёрст',1066.8],['sazhen','Сажень','саж.',2.1336],['arshin','Аршин','арш.',0.7112],['vershok','Вершок','верш.',0.04445]]};
  function linear(cfg,from,v){
    var f=cfg.list.filter(function(u){return u[0]===from;})[0]; if(!f) throw new Error('unit');
    var base=v*f[3], out={}; cfg.list.forEach(function(u){out[u[0]]=base/u[3];}); return {ok:true,values:out};
  }
  var TEMP={list:[['c','Цельсий','°C'],['f','Фаренгейт','°F'],['k','Кельвин','K'],['re','Реомюр','°Ré'],['ra','Ранкин','°R']]};
  var toK={c:function(v){return v+273.15;},f:function(v){return (v+459.67)*5/9;},k:function(v){return v;},re:function(v){return v*1.25+273.15;},ra:function(v){return v*5/9;}};
  var fromK={c:function(k){return k-273.15;},f:function(k){return k*9/5-459.67;},k:function(k){return k;},re:function(k){return (k-273.15)*0.8;},ra:function(k){return k*9/5;}};
  function temp(from,v){
    var k=toK[from](v);
    if(k<-1e-9) return {ok:false,error:'Ниже абсолютного нуля (0 K = −273,15 °C = −459,67 °F) температура быть не может.'};
    var out={}; Object.keys(fromK).forEach(function(u){out[u]=fromK[u](Math.max(0,k));}); return {ok:true,values:out};
  }
  function parse(s){ s=String(s).replace(/\s|\u00a0/g,'').replace(',','.').replace(/^[−–]/,'-'); if(s===''||!/^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(s)) return NaN; return parseFloat(s); }
  function fmt(x){ // до 10 значащих цифр, без хвостовых нулей, десятичная запятая
    if(!isFinite(x)) return ''; if(Math.abs(x)<1e-12) return '0';
    var a=Math.abs(x), s;
    if(a>=1e15||a<1e-7) s=x.toExponential(6).replace(/\.?0+e/,'e');
    else { s=String(Number(x.toPrecision(10))); if(/e/.test(s)) s=Number(x.toPrecision(10)).toFixed(12).replace(/\.?0+$/,''); }
    return s.replace('.',',').replace(/^-/,'−');
  }
  var api={WEIGHT:WEIGHT,LENGTH:LENGTH,TEMP:TEMP,weight:function(f,v){return linear(WEIGHT,f,v);},length:function(f,v){return linear(LENGTH,f,v);},temp:temp,parse:parse,fmt:fmt};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.UnitsCalc=api;
})(this);
