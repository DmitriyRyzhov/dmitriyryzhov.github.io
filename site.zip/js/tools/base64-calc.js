/* Base64 (без DOM, тестируется в Node): UTF-8, URL-safe, байты. */
(function(root){
  'use strict';
  var A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function utf8(s){return new TextEncoder().encode(s);}
  function fromBytes(b,urlSafe){var o='',i;for(i=0;i+2<b.length;i+=3){var n=b[i]<<16|b[i+1]<<8|b[i+2];o+=A[n>>18&63]+A[n>>12&63]+A[n>>6&63]+A[n&63];}
    var r=b.length-i; if(r===1){var x=b[i]<<16;o+=A[x>>18&63]+A[x>>12&63]+'==';} else if(r===2){var y=b[i]<<16|b[i+1]<<8;o+=A[y>>18&63]+A[y>>12&63]+A[y>>6&63]+'=';}
    if(urlSafe) o=o.replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); return o;}
  function clean(s){ s=String(s).replace(/^data:[^,]*;base64,/i,'').replace(/[\s\r\n]/g,'').replace(/-/g,'+').replace(/_/g,'/');
    if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)) throw new Error('Недопустимые символы: Base64 содержит только A–Z, a–z, 0–9, +, / (или -, _) и = в конце.');
    s=s.replace(/=+$/,''); if(s.length%4===1) throw new Error('Неверная длина строки Base64 — похоже, она обрезана.'); return s; }
  function toBytes(s){ s=clean(s); var out=new Uint8Array(Math.floor(s.length*3/4)),j=0,buf=0,bits=0;
    for(var i=0;i<s.length;i++){buf=buf<<6|A.indexOf(s[i]);bits+=6;if(bits>=8){bits-=8;out[j++]=buf>>bits&255;}} return out.subarray(0,j); }
  function encode(text,urlSafe){return fromBytes(utf8(text),urlSafe);}
  function decode(b64){ var b=toBytes(b64); try{ return {ok:true,text:new TextDecoder('utf-8',{fatal:true}).decode(b),bytes:b}; }catch(e){ return {ok:true,text:null,bytes:b,binary:true}; } }
  function sniff(b){ // тип по сигнатуре
    var h=function(a){for(var i=0;i<a.length;i++) if(b[i]!==a[i]) return false; return b.length>=a.length;};
    if(h([137,80,78,71])) return 'image/png'; if(h([255,216,255])) return 'image/jpeg'; if(h([71,73,70,56])) return 'image/gif';
    if(h([82,73,70,70])&&b[8]===87&&b[9]===69) return 'image/webp'; if(h([37,80,68,70])) return 'application/pdf'; if(h([80,75,3,4])) return 'application/zip';
    var t=''; try{t=new TextDecoder().decode(b.subarray(0,200));}catch(e){} if(/^\s*<svg|^\s*<\?xml[^>]*>\s*<svg/i.test(t)) return 'image/svg+xml';
    return 'application/octet-stream'; }
  var api={encode:encode,decode:decode,fromBytes:fromBytes,toBytes:toBytes,sniff:sniff};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.B64=api;
})(this);
