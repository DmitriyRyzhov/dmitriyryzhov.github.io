/* Конвертер дат: формат/GMT входа → сдвиг → формат/GMT выхода (логика в timestamp-fmt.js) */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var browserOff=-new Date().getTimezoneOffset();
  ['inoff','outoff'].forEach(function(id){
    var sel=$(id), list=TsFmt.OFFSETS.slice(); if(list.indexOf(browserOff)<0) list.push(browserOff);
    list.sort(function(x,y){return x-y;}).forEach(function(o){ var op=document.createElement('option'); op.value=o; op.textContent=TsFmt.offLabel(o); if(o===browserOff) op.selected=true; sel.appendChild(op); });
  });
  /** Ключ формата из селектора (+ поле своего шаблона) */
  function key(sel,custom){ return $(sel).value==='custom' ? ($(custom).value||'YYYY-MM-DD') : $(sel).value; }
  function convert(){
    $('incustomwrap').hidden=$('infmt').value!=='custom'; $('outcustomwrap').hidden=$('outfmt').value!=='custom';
    var src=$('cin').value, inOff=+$('inoff').value, ms, note='';
    if(!src.trim()){ show('—','—',''); $('cinfo').textContent=$('ininfo').textContent=''; return; }
    if($('infmt').value==='auto'){ var r=TsFmt.detect(src,inOff); ms=r?r.ms:NaN; if(r) note='Распознано: '+r.fmt; }
    else ms=TsFmt.parse(src,key('infmt','incustom'),inOff);
    if(isNaN(ms)){ show('Не удалось разобрать дату','—',''); $('cinfo').textContent=$('ininfo').textContent=''; return; }
    $('ininfo').textContent='Вход: '+describe(ms,inOff);
    ms=TsFmt.shift(ms,$('sd').value,$('sh').value,$('sm').value);
    $('cinfo').textContent=describe(ms,+$('outoff').value)+', '+TsFmt.info(ms,+$('outoff').value).doy+'-й день года';
    show(TsFmt.format(ms,key('outfmt','outcustom'),+$('outoff').value), Math.floor(ms/1000)+' с / '+ms+' мс', note);
  }
  /** «воскресенье, 41-я неделя 2026 (ISO)» */
  function describe(ms,off){ var I=TsFmt.info(ms,off); return I.dow+', '+I.week+'-я неделя '+I.weekYear+' (ISO)'; }
  function show(res,ts,note){ $('cout').textContent=res; $('cts').textContent=ts; $('cnote').textContent=note; }
  ['cin','infmt','incustom','inoff','outfmt','outcustom','outoff','sd','sh','sm'].forEach(function(id){$(id).addEventListener('input',convert);});
  // кнопки +/- у полей сдвига
  document.querySelectorAll('[data-step]').forEach(function(b){ b.addEventListener('click',function(){ var f=$(b.dataset.field); f.value=(+f.value||0)+(+b.dataset.step); convert(); }); });
  $('cin').value=TsFmt.format(Date.now(),'YYYYMMDD',browserOff); convert();
  document.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){copyText($(b.dataset.copy).textContent);});});
})();
