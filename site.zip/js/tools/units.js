/* Конвертеры единиц (UI); расчёт в units-calc.js */
(function(){
  'use strict';
  var box=document.getElementById('units'); if(!box) return;
  var kind=box.dataset.kind, U=UnitsCalc, cfg=kind==='temp'?U.TEMP:(kind==='weight'?U.WEIGHT:U.LENGTH), err=document.getElementById('uerr');
  box.innerHTML=cfg.list.map(function(u){return '<div class="u-row"><label for="u-'+u[0]+'">'+u[1]+' <small>('+u[2]+')</small></label><div class="u-in"><input id="u-'+u[0]+'" data-u="'+u[0]+'" type="text" inputmode="decimal" autocomplete="off"><button type="button" class="u-copy" data-u="'+u[0]+'" aria-label="Скопировать: '+u[1]+'" title="Скопировать"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/></svg></button></div></div>';}).join('');
  var inputs=box.querySelectorAll('input');
  function update(src){
    var v=U.parse(src.value); src.classList.remove('bad');
    if(isNaN(v)){ if(src.value.trim()!==''){src.classList.add('bad'); err.textContent='Введите число, например 12,5';} else err.textContent=''; return; }
    var r=U[kind](src.dataset.u,v);
    if(!r.ok){src.classList.add('bad'); err.textContent=r.error; return;}
    err.textContent='';
    inputs.forEach(function(i){ if(i!==src) i.value=U.fmt(r.values[i.dataset.u]); });
  }
  inputs.forEach(function(i){i.addEventListener('input',function(){update(i);});});
  box.addEventListener('click',function(e){var b=e.target.closest('.u-copy'); if(!b) return; var i=document.getElementById('u-'+b.dataset.u); if(i.value) copyText(i.value);});
  var first=document.getElementById('u-'+box.dataset.start); first.value=box.dataset.value; update(first);
})();
