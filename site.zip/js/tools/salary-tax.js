/* Налоговый калькулятор (UI); расчёт в salary-tax-calc.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, mode='gross', per='m';
  var M=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  function rub(x){return Math.round(x).toLocaleString('ru-RU')+' ₽';}
  function pct(x){return (x*100).toLocaleString('ru-RU',{maximumFractionDigits:2})+'%';}
  function seg(id,cb){var b=$(id).querySelectorAll('button');b.forEach(function(x){x.addEventListener('click',function(){b.forEach(function(y){y.setAttribute('aria-checked',y===x);});cb(x.dataset.v);calc();});});}
  function calc(){
    var it=$('it').checked; $('emp').disabled=it;
    var opt={employer:it?'it':$('emp').value,injury:+$('inj').value};
    var v=Math.max(0,+$('amount').value||0); if(per==='y') v/=12;
    var g=mode==='gross'?v:SalaryTax.grossFromNet(v,opt);
    var R=SalaryTax.calc(g,opt);
    $('lbl').textContent=(mode==='gross'?'Зарплата до вычета НДФЛ':'Зарплата на руки')+(per==='m'?', ₽ в месяц':', ₽ в год');
    $('solved').textContent=mode==='net'?'Оклад до вычета: '+rub(g)+' в месяц ('+rub(g*12)+' в год)':'';
    $('ndflY').textContent=rub(R.ndfl); $('ndflM').textContent=rub(R.ndfl/12); $('eff').textContent=pct(R.effRate);
    $('br').innerHTML=R.brackets.filter(function(b){return b.base>0;}).map(function(b){
      return '<tr><td>'+pct(b.rate)+'</td><td>'+(b.to===Infinity?'свыше '+rub(b.from):rub(b.from)+' – '+rub(b.to))+'</td><td>'+rub(b.base)+'</td><td>'+rub(b.tax)+'</td></tr>';}).join('');
    var kk={};R.kick.forEach(function(k){kk[k.month]=k.rate;});
    $('mt').innerHTML=R.months.map(function(r){return '<tr'+(kk[r.month]?' class="kick"':'')+'><td>'+M[r.month-1]+(kk[r.month]?' ⚠ ставка '+pct(kk[r.month]):'')+'</td><td>'+rub(r.cumGross)+'</td><td>'+rub(r.ndfl)+'</td><td>'+rub(r.net)+'</td><td>'+rub(r.contrib+r.injury)+'</td></tr>';}).join('');
    $('kick').textContent=R.kick.length?R.kick.map(function(k){return 'с '+M[k.month-1].toLowerCase().replace(/ь$/,'я').replace(/й$/,'я').replace(/т$/,'та')+' — '+pct(k.rate);}).join(', '):'Весь год — 13% (доход не превышает 2,4 млн ₽).';
    $('cY').textContent=rub(R.contrib); $('iY').textContent=rub(R.injury); $('eY').textContent=rub(R.employerTaxes); $('eM').textContent=rub(R.employerTaxes/12);
    $('ctx').textContent='Тариф: '+R.employer+'. Предельная база 2026: '+rub(SalaryTax.BASE)+(R.grossYear>SalaryTax.BASE?' — будет превышена, сверх неё ставка ниже.':' — не превышена.');
    $('net').textContent=rub(R.net)+' / год ('+rub(R.netMonthlyAvg)+' в мес. в среднем)';
    $('cost').textContent=rub(R.cost)+' / год'; $('tot').textContent=rub(R.taxes)+' / год';
    $('per100').textContent=R.cost?(R.statePer100.toLocaleString('ru-RU',{maximumFractionDigits:1})+' ₽'):'—';
    var parts=[[R.net,'#16a34a','На руки'],[R.ndfl,'#dc2626','НДФЛ'],[R.contrib,'#f59e0b','Страховые взносы'],[R.injury,'#7c3aed','Травматизм']];
    $('bar').innerHTML=parts.map(function(p){var w=R.cost?p[0]/R.cost*100:0;return '<span style="width:'+w+'%;background:'+p[1]+'" title="'+p[2]+': '+rub(p[0])+'">'+(w>8?Math.round(w)+'%':'')+'</span>';}).join('');
    $('leg').innerHTML=parts.map(function(p){return '<span><i style="background:'+p[1]+'"></i>'+p[2]+': '+rub(p[0])+'</span>';}).join('');
  }
  seg('mode',function(v){mode=v;}); seg('per',function(v){
    var a=$('amount'); if(v!==per){a.value=Math.round(v==='y'?a.value*12:a.value/12);} per=v;});
  ['amount','emp','inj','it'].forEach(function(id){$(id).addEventListener('input',calc);$(id).addEventListener('change',calc);});
  calc();
})();
