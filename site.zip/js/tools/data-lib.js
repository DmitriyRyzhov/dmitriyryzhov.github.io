/* Библиотека преобразования данных (без DOM, тестируется в Node):
   CSV (RFC 4180) парсер/сериализатор, автоопределение разделителя и формата,
   flatten/unflatten вложенных структур, построение таблицы из любых данных. */
(function(root){
  'use strict';
  var DELIMS=[',',';','\t','|'];

  /** RFC 4180: кавычки "", удвоенные "" внутри, переносы строк внутри кавычек, CRLF/LF/CR */
  function parseCSV(text,delim){
    var rows=[], row=[], f='', i=0, q=false, c, n=text.length;
    if(text.charCodeAt(0)===0xFEFF) i=1; // BOM
    for(;i<n;i++){
      c=text[i];
      if(q){
        if(c==='"'){ if(text[i+1]==='"'){ f+='"'; i++; } else q=false; }
        else f+=c;
      } else if(c==='"' && f===''){ q=true; }
      else if(c===delim){ row.push(f); f=''; }
      else if(c==='\r'||c==='\n'){ if(c==='\r'&&text[i+1]==='\n') i++; row.push(f); rows.push(row); row=[]; f=''; }
      else f+=c;
    }
    if(q) throw new Error('Незакрытая кавычка в CSV');
    if(f!==''||row.length) { row.push(f); rows.push(row); }
    return rows;
  }
  /** Подсчёт разделителя вне кавычек по первым строкам; выбираем самый «стабильный» */
  function detectDelimiter(text){
    var sample=text.slice(0,20000), best=',', bestScore=-1;
    DELIMS.forEach(function(d){
      var counts=[], cnt=0, q=false;
      for(var i=0;i<sample.length&&counts.length<20;i++){
        var c=sample[i];
        if(c==='"') q=!q; else if(!q&&c===d) cnt++; else if(!q&&c==='\n'){ counts.push(cnt); cnt=0; }
      }
      if(cnt||!counts.length) counts.push(cnt);
      var nz=counts.filter(function(x){return x>0;}); if(!nz.length) return;
      var same=counts.filter(function(x){return x===counts[0];}).length/counts.length;
      var score=same*10+Math.min(nz.length,10)+Math.min(counts[0],50)/50;
      if(score>bestScore){ bestScore=score; best=d; }
    });
    return best;
  }
  function esc(v,delim){
    if(v===null||v===undefined) return '';
    v= typeof v==='object' ? JSON.stringify(v) : String(v);
    return /[",\r\n]/.test(v)||v.indexOf(delim)>=0||/^\s|\s$/.test(v) ? '"'+v.replace(/"/g,'""')+'"' : v;
  }
  /** Массив строк (массивов) -> CSV текст (CRLF по RFC 4180) */
  function toCSV(aoa,delim){ delim=delim||','; return aoa.map(function(r){return r.map(function(v){return esc(v,delim);}).join(delim);}).join('\r\n'); }

  function isObj(v){ return v!==null && typeof v==='object' && !(v instanceof Date); }
  /** {a:{b:1},c:[{d:2}]} -> {"a.b":1,"c.0.d":2}; пустые объекты/массивы сохраняются как {} / [] */
  function flatten(v,prefix,out){
    out=out||{}; prefix=prefix||'';
    if(!isObj(v)){ out[prefix||'value']=v instanceof Date? v.toISOString() : v; return out; }
    var keys=Object.keys(v);
    if(!keys.length){ out[prefix||'value']=Array.isArray(v)?[]:{}; return out; }
    keys.forEach(function(k){ flatten(v[k],prefix?prefix+'.'+k:k,out); });
    return out;
  }
  /** Обратно: числовые сегменты -> массивы */
  function unflatten(o){
    var res={};
    Object.keys(o).forEach(function(key){
      var parts=key.split('.'), cur=res;
      for(var i=0;i<parts.length;i++){
        var p=parts[i], last=i===parts.length-1;
        if(last){ cur[p]=o[key]; }
        else { if(!isObj(cur[p])) cur[p]= /^\d+$/.test(parts[i+1])?[]:{}; cur=cur[p]; }
      }
    });
    return compactArrays(res);
  }
  function compactArrays(v){ // массивы из числовых ключей могут быть разреженными — убираем дыры
    if(Array.isArray(v)) return v.filter(function(x){return x!==undefined;}).map(compactArrays);
    if(isObj(v)){ Object.keys(v).forEach(function(k){v[k]=compactArrays(v[k]);}); }
    return v;
  }
  /** Типизация строки из CSV: числа (без ведущих нулей), true/false, null; пустая строка остаётся '' */
  function inferType(s){
    if(typeof s!=='string') return s;
    if(/^-?(0|[1-9]\d{0,14})(\.\d+)?([eE][+-]?\d+)?$/.test(s)) return Number(s);
    if(s==='true') return true; if(s==='false') return false; if(s==='null') return null;
    return s;
  }
  /** Строки CSV/Excel (aoa) -> JS данные: массив объектов (с заголовками) или массив массивов */
  function rowsToData(aoa,opts){
    opts=opts||{}; var conv=opts.types?inferType:function(x){return x;};
    aoa=aoa.filter(function(r){return r.some(function(x){return x!==''&&x!==null&&x!==undefined;});});
    if(!opts.headers) return aoa.map(function(r){return r.map(conv);});
    if(!aoa.length) return [];
    var h=aoa[0].map(function(x,i){ x=String(x===undefined||x===null?'':x).trim(); return x||'column'+(i+1); });
    var seen={}; h=h.map(function(x){ if(seen[x]){ seen[x]++; return x+'_'+seen[x]; } seen[x]=1; return x; }); // дубли
    return aoa.slice(1).map(function(r){
      var o={}; h.forEach(function(k,i){ o[k]=conv(r[i]===undefined?'':r[i]); });
      return opts.nest && h.some(function(k){return k.indexOf('.')>0;}) ? unflatten(o) : o;
    });
  }
  /** Максимальная глубина вложенности (ограничена для скорости) */
  function depth(v,lim){ lim=lim||50; if(!isObj(v)||lim<=0) return 0; var m=0; for(var k in v){ var d=depth(v[k],lim-1); if(d>m) m=d; } return m+1; }
  /** Любые данные -> {columns, rows(aoa), total}. Массив объектов → строки; объект → одна строка;
      массив массивов → колонки 1..n. maxRows ограничивает только rows (total — полное число). */
  function toTable(data,maxRows){
    maxRows=maxRows||Infinity;
    var items = Array.isArray(data) ? data : [data], cols=[], idx={}, flat=[];
    var aoa = items.length && items.every(Array.isArray) && items.every(function(r){return r.every(function(x){return !isObj(x);});});
    if(aoa){
      var w=Math.max.apply(null,items.map(function(r){return r.length;}).concat([0]));
      for(var j=0;j<w;j++) cols.push(String(j+1));
      return {columns:cols, rows:items.slice(0,maxRows).map(function(r){ var o=r.slice(); while(o.length<w) o.push(''); return o; }), total:items.length, aoa:true};
    }
    items.forEach(function(it,n){
      var f=flatten(it); if(n<maxRows) flat.push(f);
      for(var k in f) if(!(k in idx)){ idx[k]=cols.length; cols.push(k); }
    });
    return {columns:cols, rows:flat.map(function(f){ return cols.map(function(c){ var v=f[c]; return v===undefined?'':v; }); }), total:items.length};
  }
  /** Данные -> aoa с заголовком (для CSV/XLSX выгрузки) */
  function toAOA(data){ var t=toTable(data); return t.aoa? t.rows : [t.columns].concat(t.rows); }
  /** Позиция первой синтаксической ошибки JSON (собственный мини-сканер; нужен, т.к. не все движки сообщают позицию) */
  function jsonErrorPos(t){
    var i=0, n=t.length;
    function ws(){ while(i<n&&/[ \t\r\n]/.test(t[i])) i++; }
    function fail(){ throw i; }
    function val(){
      ws(); var c=t[i];
      if(c==='{'){ i++; ws(); if(t[i]==='}'){i++;return;} for(;;){ ws(); if(t[i]!=='"') fail(); str(); ws(); if(t[i]!==':') fail(); i++; val(); ws(); if(t[i]===','){i++;continue;} if(t[i]==='}'){i++;return;} fail(); } }
      if(c==='['){ i++; ws(); if(t[i]===']'){i++;return;} for(;;){ val(); ws(); if(t[i]===','){i++;continue;} if(t[i]===']'){i++;return;} fail(); } }
      if(c==='"') return str();
      var m=/^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?/.exec(t.slice(i,i+400)); if(m&&m[0]){ i+=m[0].length; return; }
      var k=['true','false','null']; for(var j=0;j<3;j++) if(t.substr(i,k[j].length)===k[j]){ i+=k[j].length; return; }
      fail();
    }
    function str(){ i++; while(i<n){ var c=t[i]; if(c==='"'){i++;return;} if(c==='\\'){ i++; if(t[i]==='u'){ if(!/^[0-9a-fA-F]{4}$/.test(t.substr(i+1,4))) fail(); i+=5; continue; } if('"\\/bfnrt'.indexOf(t[i])<0) fail(); i++; continue; } if(c<' ') fail(); i++; } fail(); }
    try{ if(t.charCodeAt(0)===0xFEFF) i=1; val(); ws(); if(i<n) fail(); return -1; }catch(e){ if(typeof e==='number') return e; throw e; }
  }
  /** Сообщение об ошибке JSON с номером строки и столбца */
  function jsonError(e,text){
    var p=jsonErrorPos(text), m, line, col;
    if(p<0){ m=/position (\d+)/.exec(e.message); if(m) p=+m[1]; }
    if(p>=0){ var b=text.slice(0,p).split('\n'); line=b.length; col=b[b.length-1].length+1; }
    var near= p>=0 ? (p>=text.length?' — неожиданный конец данных':' — рядом с «'+text.slice(p,p+15).replace(/\n/g,'⏎')+'»') : '';
    return 'Некорректный JSON'+(line?' в строке '+line+', столбце '+col:'')+near+'. ('+e.message.split('\n')[0]+')';
  }
  /** Автоопределение формата текста: 'json' | 'csv' */
  function detectFormat(text){
    var t=text.replace(/^\uFEFF/,'').trim();
    if(/^[\[{]/.test(t)){ try{ JSON.parse(t); return 'json'; }catch(e){ if(/^\{/.test(t)||/^\[\s*[\[{"\d-tfn\]]/.test(t)) return 'json'; } }
    return 'csv';
  }
  var lib={parseCSV:parseCSV,detectDelimiter:detectDelimiter,toCSV:toCSV,flatten:flatten,unflatten:unflatten,inferType:inferType,
    rowsToData:rowsToData,depth:depth,toTable:toTable,toAOA:toAOA,jsonError:jsonError,jsonErrorPos:jsonErrorPos,detectFormat:detectFormat};
  if(typeof module!=='undefined'&&module.exports) module.exports=lib; else root.DataLib=lib;
})(this);
