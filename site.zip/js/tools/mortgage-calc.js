/* Расчёт аннуитетного кредита с досрочными погашениями (без DOM, тестируется в Node).
   extras: [{amount, month, type:'once'|'monthly'|'yearly', until?}] — платёж вносится в конце месяца month
   после обычного платежа. mode: 'term' (уменьшение срока) | 'payment' (уменьшение платежа). */
(function(root){
  'use strict';
  /** Аннуитетный платёж */
  function annuity(P,r,n){ return n<=0?P : r===0 ? P/n : P*r/(1-Math.pow(1+r,-n)); }
  /** Сумма досрочки в месяце i */
  function extraFor(extras,i){
    var s=0;
    (extras||[]).forEach(function(e){
      var a=+e.amount, m=Math.round(+e.month); if(!(a>0&&m>=1)) return;
      if(e.type==='once'&&i===m) s+=a;
      else if(e.type==='monthly'&&i>=m) s+=a;
      else if(e.type==='yearly'&&i>=m&&(i-m)%12===0) s+=a;
    });
    return s;
  }
  function simulate(P,annualRate,n,extras,mode){
    var r=annualRate/100/12, pay=annuity(P,r,n), first=pay, bal=P, rows=[], interest=0, paid=0, extraSum=0, eps=1e-6;
    for(var i=1;bal>eps&&i<=n;i++){
      var int=bal*r, p=Math.min(pay,bal+int), princ=p-int;   // последний платёж может быть неполным
      bal-=princ; interest+=int; paid+=p;
      var ex=Math.min(extraFor(extras,i),Math.max(bal,0));
      bal-=ex; paid+=ex; extraSum+=ex;
      if(bal<eps) bal=0;
      rows.push({i:i,pay:p,princ:princ,int:int,extra:ex,bal:bal});
      if(ex>0&&mode==='payment'&&bal>0) pay=annuity(bal,r,n-i); // пересчёт на остаток срока
    }
    return {rows:rows,firstPay:first,lastPay:rows.length?rows[rows.length-1].pay:0,
      // «платёж после» — регулярный платёж после последней досрочки (не учитывая неполный последний)
      payAfter:pay,months:rows.length,interest:interest,total:paid,extra:extraSum};
  }
  /** Три сценария для сравнения */
  function compare(P,rate,n,extras){
    var base=simulate(P,rate,n,[],'term'), t=simulate(P,rate,n,extras,'term'), p=simulate(P,rate,n,extras,'payment');
    [t,p].forEach(function(s){ s.saved=base.interest-s.interest; s.savedPct=base.interest?s.saved/base.interest*100:0; s.monthsSaved=base.months-s.months; });
    base.saved=0; base.savedPct=0; base.monthsSaved=0;
    return {base:base,term:t,payment:p};
  }
  var lib={annuity:annuity,simulate:simulate,compare:compare};
  if(typeof module!=='undefined'&&module.exports) module.exports=lib; else root.MortgageCalc=lib;
})(this);
