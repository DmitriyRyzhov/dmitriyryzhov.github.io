/* Рабочие дни по производственному календарю (UI); расчёт в date-lib.js, данные в prodcal-data.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, L=DateLib, P=L.PC;
  var M=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  function n(x){return Number(x).toLocaleString('ru-RU',{maximumFractionDigits:1});}
  var ty=new Date().getFullYear(); if(P.YEARS.indexOf(ty)<0) ty=P.YEARS[P.YEARS.length-1];
  $('year').innerHTML=P.YEARS.map(function(y){return '<option'+(y===ty?' selected':'')+'>'+y+'</option>';}).join('');
  $('from').value=ty+'-01-01'; $('to').value=ty+'-12-31'; $('start').value=L.iso(L.todayLocal());
  function period(){
    var a=L.parse($('from').value),b=L.parse($('to').value); if(isNaN(a)||isNaN(b)||b<a){$('pout').hidden=true;$('perr').textContent=isNaN(a)||isNaN(b)?'':'Конец периода раньше начала.';return;}
    $('perr').textContent=''; $('pout').hidden=false; var s=L.workStats(a,b);
    $('pc').textContent=n(s.calendar); $('pw').textContent=n(s.work)+(s.short?' (из них сокращённых: '+s.short+')':''); $('po').textContent=n(s.off)+' (праздничных: '+s.holidays+')';
    $('h40').textContent=n(s.h40)+' ч'; $('h36').textContent=n(s.h36)+' ч'; $('h24').textContent=n(s.h24)+' ч';
    $('pwarn').textContent=s.unknownYears.length?'Для '+s.unknownYears.join(', ')+' г. официального календаря нет — учтены только выходные и праздники по ТК РФ, без переносов.':'';
  }
  function add(){var s=L.parse($('start').value),k=Math.trunc(+$('nw').value||0); if(isNaN(s)){$('addres').textContent='';return;}
    var d=L.addWorkdays(s,($('dir').value==='-'?-1:1)*k); $('addres').textContent=L.iso(d).split('-').reverse().join('.')+' — '+L.WD[L.wd(d)];}
  function year(){
    var y=+$('year').value, d=P.DATA[y], html='', tot=L.workStats(L.parse(y+'-01-01'),L.parse(y+'-12-31'));
    for(var m=1;m<=12;m++){
      var first=L.parse(y+'-'+(m<10?'0':'')+m+'-01'), days=new Date(Date.UTC(y,m,0)).getUTCDate(), st=L.workStats(first,first+days-1);
      var cells='<tr>'+'пн вт ср чт пт сб вс'.split(' ').map(function(x){return '<th>'+x+'</th>';}).join('')+'</tr><tr>', off=L.wd(first);
      for(var i=0;i<off;i++) cells+='<td></td>';
      for(var dd=1;dd<=days;dd++){var nn=first+dd-1,t=L.dayType(nn),k=(m<10?'0':'')+m+'-'+(dd<10?'0':'')+dd, nm=P.NAMES[k];
        cells+='<td class="wd-'+t+'"'+(nm&&t==='holiday'?' title="'+nm+'"':t==='short'?' title="Предпраздничный день, на 1 час короче"':'')+'>'+dd+(t==='short'?'*':'')+'</td>'; if((off+dd)%7===0&&dd<days) cells+='</tr><tr>';}
      html+='<div class="wd-month"><h3>'+M[m-1]+'</h3><table>'+cells+'</tr></table><p>Рабочих: <b>'+st.work+'</b> · выходных: '+st.off+' · '+n(st.h40)+' ч</p></div>';
    }
    $('cal').innerHTML=html;
    $('ysum').textContent=y+' год: '+tot.calendar+' календарных дней, '+tot.work+' рабочих, '+tot.off+' выходных и праздничных. Норма часов: '+n(tot.h40)+' (40 ч), '+n(tot.h36)+' (36 ч), '+n(tot.h24)+' (24 ч).';
    $('ysrc').textContent=d?'Основание: '+d.src+'.':'';
  }
  ['from','to'].forEach(function(id){$(id).addEventListener('change',period);$(id).addEventListener('input',period);});
  ['start','nw','dir'].forEach(function(id){$(id).addEventListener('change',add);$(id).addEventListener('input',add);});
  $('year').addEventListener('change',year);
  period(); add(); year();
})();
