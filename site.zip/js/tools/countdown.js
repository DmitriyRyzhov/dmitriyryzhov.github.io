/* Обратный отсчёт (UI); расчёт в date-lib.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, L=DateLib, timer=null;
  function pad(x){return (x<10?'0':'')+x;}
  function pl(x,a,b,c){x=Math.abs(x)%100;var y=x%10;return x>10&&x<20?c:y===1?a:y>=2&&y<=4?b:c;}
  function localISO(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());}
  function ny(){return new Date(new Date().getFullYear()+1,0,1,0,0);}
  function setPreset(p){
    var now=new Date();
    if(p==='ny'){$('to').value=localISO(ny());$('name').value='Новый год';}
    else if(p==='bday'){$('name').value='День рождения';$('to').focus();}
    else if(p==='vac'){$('name').value='Отпуск';var d=new Date(now.getFullYear(),now.getMonth()+1,1,9,0);$('to').value=localISO(d);}
    else {$('name').value='';$('to').focus();}
    tick(); share();
  }
  function target(){var v=$('to').value; if(!v) return null; var d=new Date(v); return isNaN(d)?null:d;}
  function tick(){
    var t=target(); if(!t){$('big').textContent='—';return;}
    var c=L.countdown(Date.now(),t.getTime()), nm=$('name').value.trim()||'события';
    $('title').textContent=(c.past?'С момента: ':'До: ')+nm;
    $('dd').textContent=c.days; $('ddl').textContent=pl(c.days,'день','дня','дней'); $('hh').textContent=pad(c.hours); $('mm').textContent=pad(c.minutes); $('ss').textContent=pad(c.seconds);
    var today=L.todayLocal(), td=Date.UTC(t.getFullYear(),t.getMonth(),t.getDate())/86400000;
    $('wleft').textContent=!c.past&&td>today?'Рабочих дней до даты (по производственному календарю РФ, не считая сегодня): '+L.workStats(today+1,td-1).work:'';
    $('done').hidden=!c.past;
  }
  function share(){var t=$('to').value,u=location.href.split('?')[0]+'?to='+encodeURIComponent(t)+($('name').value.trim()?'&name='+encodeURIComponent($('name').value.trim()):''); $('url').value=t?u:''; }
  document.querySelectorAll('[data-p]').forEach(function(b){b.addEventListener('click',function(){setPreset(b.dataset.p);});});
  ['to','name'].forEach(function(id){$(id).addEventListener('input',function(){tick();share();});});
  $('copy').addEventListener('click',function(){if($('url').value) copyText($('url').value);});
  var q=new URLSearchParams(location.search);
  if(q.get('to')&&!isNaN(new Date(q.get('to')))){$('to').value=q.get('to').slice(0,16);$('name').value=(q.get('name')||'').slice(0,80);} else setPreset('ny');
  tick(); share(); timer=setInterval(tick,1000);
})();
