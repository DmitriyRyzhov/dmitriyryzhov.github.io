/* Космический тир — мини-игра в духе Galaxian. Vanilla JS + canvas, вся графика рисуется кодом. */
(function(){
  'use strict';
  var cv=document.getElementById('game'); if(!cv) return;
  var ctx=cv.getContext('2d'), W=480, H=640, scale=1, dpr=1;
  var $=function(id){return document.getElementById(id);};
  var HS_KEY='cogle-shooter-hs', hs=+(localStorage.getItem(HS_KEY)||0);
  var COLORS=['#f9a8d4','#c4b5fd','#93c5fd','#86efac','#fde68a'];
  var st={mode:'start',score:0,lives:3,level:1,t:0}, P, shots, bombs, aliens, sparks, stars, keys={}, sound=false, fireCd=0, diveCd=2, sway=0, banner=0, inv=0;
  var MAXSHOTS=3;
  // ---------- размер ----------
  function resize(){
    var wrap=cv.parentElement, maxW=Math.min(wrap.clientWidth,480), maxH=Math.max(320,window.innerHeight-140);
    scale=Math.min(maxW/W,maxH/H); dpr=Math.min(window.devicePixelRatio||1,2);
    cv.style.width=Math.round(W*scale)+'px'; cv.style.height=Math.round(H*scale)+'px';
    cv.width=Math.round(W*scale*dpr); cv.height=Math.round(H*scale*dpr);
    ctx.setTransform(scale*dpr,0,0,scale*dpr,0,0);
  }
  // ---------- звук ----------
  var ac=null;
  function beep(f,d,type,vol){ if(!sound) return; try{ ac=ac||new (window.AudioContext||window.webkitAudioContext)(); var o=ac.createOscillator(),g=ac.createGain();
    o.type=type||'square'; o.frequency.value=f; g.gain.value=vol||0.04; g.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+d); o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime+d);}catch(e){} }
  // ---------- инициализация ----------
  function initStars(){ stars=[]; for(var i=0;i<90;i++) stars.push({x:Math.random()*W,y:Math.random()*H,s:Math.random()*1.6+0.4,v:20+Math.random()*60}); }
  function wave(){
    aliens=[]; var rows=5, cols=8;
    for(var r=0;r<rows;r++) for(var c=0;c<cols;c++)
      aliens.push({r:r,c:c,hx:60+c*48,hy:70+r*40,x:0,y:0,state:'form',t:0,col:COLORS[r],pts:(rows-r)*10+20,blink:Math.random()*5});
    shots=[]; bombs=[]; diveCd=2.5; sway=0; banner=1.6;
  }
  function reset(){ st.score=0; st.lives=3; st.level=1; P={x:W/2,y:H-50,w:34}; sparks=[]; inv=0; wave(); }
  function diff(){ return {sway:18+st.level*3, dive:Math.max(0.6,2.6-st.level*0.25), diveSpd:120+st.level*18, bomb:Math.max(0.5,1.4-st.level*0.1)}; }
  // ---------- логика ----------
  function slotPos(a){ return {x:a.hx+Math.sin(sway)*diff().sway, y:a.hy+Math.sin(sway*2+a.c)*2}; }
  function startDive(){
    var cand=aliens.filter(function(a){return a.state==='form';}); if(!cand.length) return;
    // чаще ныряют крайние в строю
    var a=cand[Math.floor(Math.random()*cand.length)], p=slotPos(a);
    a.state='dive'; a.t=0; a.sx=p.x; a.sy=p.y; a.dir=a.x<W/2?1:-1; a.tx=P.x; a.bombT=0.4+Math.random()*0.6; beep(660,0.15,'triangle');
  }
  function fire(){ if(fireCd>0||shots.length>=MAXSHOTS) return; shots.push({x:P.x,y:P.y-22}); fireCd=0.22; beep(880,0.06); }
  function pop(x,y,col,n){ for(var i=0;i<(n||14);i++){var a=Math.random()*Math.PI*2,s=40+Math.random()*120; sparks.push({x:x,y:y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:0.6+Math.random()*0.4,col:col});} }
  function hitPlayer(){ if(inv>0) return; st.lives--; pop(P.x,P.y,'#fde68a',24); beep(180,0.4,'sawtooth',0.06); inv=2;
    bombs=[]; aliens.forEach(function(a){ if(a.state==='dive'){a.state='back';a.t=0;a.y=-30;} });
    if(st.lives<=0){ st.mode='over'; if(st.score>hs){hs=st.score;try{localStorage.setItem(HS_KEY,hs);}catch(e){}} } }
  function update(dt){
    st.t+=dt;
    stars.forEach(function(s){ s.y+=s.v*dt; if(s.y>H){s.y=0;s.x=Math.random()*W;} });
    sparks.forEach(function(p){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=0.96;p.vy*=0.96;p.l-=dt;}); sparks=sparks.filter(function(p){return p.l>0;});
    if(st.mode!=='play') return;
    var D=diff(); sway+=dt*(0.9+st.level*0.08); fireCd-=dt; inv=Math.max(0,inv-dt); banner=Math.max(0,banner-dt);
    // игрок
    var mv=(keys.right?1:0)-(keys.left?1:0); if(drag!==null){ var dx=drag-P.x; mv=Math.abs(dx)<4?0:Math.sign(dx)*Math.min(1,Math.abs(dx)/30); }
    P.x=Math.max(22,Math.min(W-22,P.x+mv*260*dt));
    if(keys.fire||drag!==null) fire();
    // выстрелы
    shots.forEach(function(s){s.y-=520*dt;}); shots=shots.filter(function(s){return s.y>-20;});
    bombs.forEach(function(b){b.y+=b.v*dt;}); bombs=bombs.filter(function(b){return b.y<H+10;});
    // пришельцы
    if(banner<=0){ diveCd-=dt; if(diveCd<=0){ startDive(); if(st.level>2&&Math.random()<0.35) startDive(); diveCd=D.dive*(0.6+Math.random()*0.8); } }
    aliens.forEach(function(a){
      var p=slotPos(a);
      if(a.state==='form'){ a.x=p.x; a.y=p.y; }
      else if(a.state==='dive'){
        a.t+=dt; var k=a.t;
        // петля вверх-вбок, затем дуга к игроку
        if(k<0.6){ var ang=k/0.6*Math.PI; a.x=a.sx+a.dir*-30*Math.sin(ang); a.y=a.sy-30*Math.sin(ang); }
        else { a.y+=D.diveSpd*dt; a.tx+=(P.x-a.tx)*dt*0.8; a.x+=((a.tx+Math.sin(k*3)*60)-a.x)*dt*2; }
        a.bombT-=dt; if(a.bombT<=0&&a.y>0&&a.y<H-140){ bombs.push({x:a.x,y:a.y+12,v:150+st.level*10}); a.bombT=D.bomb+Math.random(); }
        if(a.y>H+30){ a.state='back'; a.t=0; a.y=-30; a.x=p.x; }
        if(Math.abs(a.x-P.x)<22&&Math.abs(a.y-P.y)<20){ hitPlayer(); a.state='dead'; pop(a.x,a.y,a.col); }
      } else if(a.state==='back'){ a.t+=dt; a.x+=(p.x-a.x)*Math.min(1,dt*3); a.y+=(p.y-a.y)*Math.min(1,dt*3); if(Math.abs(a.y-p.y)<2&&Math.abs(a.x-p.x)<2) a.state='form'; }
      a.blink-=dt; if(a.blink<-0.15) a.blink=2+Math.random()*4;
    });
    // попадания
    shots.forEach(function(s){ aliens.forEach(function(a){ if(a.state==='dead'||s.dead) return;
      if(Math.abs(a.x-s.x)<17&&Math.abs(a.y-s.y)<15){ s.dead=true; var pts=a.state==='form'?a.pts:a.pts*2+50; st.score+=pts; a.state='dead'; pop(a.x,a.y,a.col); a.popTxt={t:0.8,pts:pts}; beep(1200,0.08,'triangle'); }
    }); });
    shots=shots.filter(function(s){return !s.dead;});
    bombs.forEach(function(b){ if(Math.abs(b.x-P.x)<16&&Math.abs(b.y-P.y)<16){ b.y=H+99; hitPlayer(); } });
    aliens.forEach(function(a){ if(a.popTxt){ a.popTxt.t-=dt; } });
    if(!aliens.some(function(a){return a.state!=='dead';})){ st.level++; wave(); beep(520,0.3,'triangle'); }
  }
  // ---------- отрисовка ----------
  function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
  function drawAlien(a){
    var x=a.x,y=a.y,wob=Math.sin(st.t*6+a.c)*2;
    ctx.fillStyle=a.col; ctx.beginPath(); ctx.ellipse(x,y,15,12,0,0,Math.PI*2); ctx.fill();
    // антенки
    ctx.strokeStyle=a.col; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(x-6,y-10); ctx.lineTo(x-9,y-17+wob); ctx.moveTo(x+6,y-10); ctx.lineTo(x+9,y-17-wob); ctx.stroke();
    ctx.beginPath(); ctx.arc(x-9,y-18+wob,2.5,0,7); ctx.arc(x+9,y-18-wob,2.5,0,7); ctx.fill();
    // глаза
    var eh=a.blink<0?0.6:4; ctx.fillStyle='#fff'; ctx.beginPath(); ctx.ellipse(x-5,y-2,4,eh,0,0,7); ctx.ellipse(x+5,y-2,4,eh,0,0,7); ctx.fill();
    if(a.blink>=0){ ctx.fillStyle='#1f2937'; ctx.beginPath(); ctx.arc(x-5,y-1,1.8,0,7); ctx.arc(x+5,y-1,1.8,0,7); ctx.fill(); }
    // улыбка и щёчки
    ctx.strokeStyle='#1f2937'; ctx.lineWidth=1.5; ctx.beginPath(); ctx.arc(x,y+3,4,0.2,Math.PI-0.2); ctx.stroke();
    ctx.fillStyle='rgba(244,114,182,.6)'; ctx.beginPath(); ctx.arc(x-10,y+4,2.2,0,7); ctx.arc(x+10,y+4,2.2,0,7); ctx.fill();
    // ножки-щупальца
    ctx.fillStyle=a.col; for(var i=-1;i<=1;i++){ ctx.beginPath(); ctx.arc(x+i*7,y+11+Math.sin(st.t*8+i)*1.5,3,0,7); ctx.fill(); }
  }
  function drawPlayer(){
    if(inv>0&&Math.floor(st.t*10)%2) return;
    var x=P.x,y=P.y;
    // пламя
    var fl=8+Math.random()*6; ctx.fillStyle='#fb923c'; ctx.beginPath(); ctx.moveTo(x-7,y+16); ctx.lineTo(x,y+16+fl); ctx.lineTo(x+7,y+16); ctx.fill();
    ctx.fillStyle='#fde68a'; ctx.beginPath(); ctx.moveTo(x-4,y+16); ctx.lineTo(x,y+12+fl*0.7); ctx.lineTo(x+4,y+16); ctx.fill();
    // крылья
    ctx.fillStyle='#ef4444'; ctx.beginPath(); ctx.moveTo(x-11,y+4); ctx.lineTo(x-20,y+17); ctx.lineTo(x-9,y+15); ctx.fill(); ctx.beginPath(); ctx.moveTo(x+11,y+4); ctx.lineTo(x+20,y+17); ctx.lineTo(x+9,y+15); ctx.fill();
    // корпус
    ctx.fillStyle='#f1f5f9'; ctx.strokeStyle='#64748b'; ctx.lineWidth=1.5; ctx.beginPath(); ctx.moveTo(x,y-22); ctx.quadraticCurveTo(x+13,y-6,x+11,y+16); ctx.lineTo(x-11,y+16); ctx.quadraticCurveTo(x-13,y-6,x,y-22); ctx.fill(); ctx.stroke();
    // уши кролика из иллюминатора
    ctx.fillStyle='#9ca3af'; ctx.beginPath(); ctx.ellipse(x-3.5,y-12,2.2,6,-0.2,0,7); ctx.ellipse(x+3.5,y-12,2.2,6,0.2,0,7); ctx.fill();
    ctx.fillStyle='#93c5fd'; ctx.beginPath(); ctx.arc(x,y-1,6.5,0,7); ctx.fill(); ctx.strokeStyle='#475569'; ctx.stroke();
    ctx.fillStyle='#9ca3af'; ctx.beginPath(); ctx.arc(x,y,4.5,0,7); ctx.fill(); ctx.fillStyle='#111'; ctx.beginPath(); ctx.arc(x-1.6,y-0.8,0.9,0,7); ctx.arc(x+1.6,y-0.8,0.9,0,7); ctx.fill();
  }
  function drawCarrot(s){ ctx.fillStyle='#fb923c'; ctx.beginPath(); ctx.moveTo(s.x-3,s.y-6); ctx.lineTo(s.x+3,s.y-6); ctx.lineTo(s.x,s.y+8); ctx.fill(); ctx.fillStyle='#22c55e'; ctx.beginPath(); ctx.moveTo(s.x,s.y-6); ctx.lineTo(s.x-3,s.y-11); ctx.lineTo(s.x+3,s.y-11); ctx.fill(); }
  function text(t,x,y,size,col,align){ ctx.font='700 '+size+'px system-ui,-apple-system,Segoe UI,sans-serif'; ctx.fillStyle=col||'#fff'; ctx.textAlign=align||'center'; ctx.fillText(t,x,y); }
  function draw(){
    var g=ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,'#1e1b4b'); g.addColorStop(1,'#312e81'); ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
    stars.forEach(function(s){ ctx.fillStyle='rgba(255,255,255,'+(0.3+s.s/3)+')'; ctx.fillRect(s.x,s.y,s.s,s.s); });
    if(st.mode!=='start'){
      aliens.forEach(function(a){ if(a.state!=='dead') drawAlien(a); else if(a.popTxt&&a.popTxt.t>0) text('+'+a.popTxt.pts,a.x,a.y-(0.8-a.popTxt.t)*30,13,'#fde68a'); });
      shots.forEach(drawCarrot);
      bombs.forEach(function(b){ ctx.fillStyle='#f0abfc'; ctx.beginPath(); ctx.arc(b.x,b.y,4,0,7); ctx.fill(); ctx.fillStyle='rgba(240,171,252,.35)'; ctx.beginPath(); ctx.arc(b.x,b.y,7,0,7); ctx.fill(); });
      if(st.mode!=='over') drawPlayer();
    }
    sparks.forEach(function(p){ ctx.globalAlpha=Math.max(0,p.l); ctx.fillStyle=p.col; ctx.beginPath(); var r=2+p.l*2; ctx.moveTo(p.x,p.y-r); ctx.lineTo(p.x+r*0.4,p.y); ctx.lineTo(p.x,p.y+r); ctx.lineTo(p.x-r*0.4,p.y); ctx.fill(); }); ctx.globalAlpha=1;
    // HUD
    text('Очки: '+st.score,12,24,16,'#fff','left'); text('Рекорд: '+Math.max(hs,st.score),W/2,24,16,'#fde68a'); text('Ур. '+st.level,W-12,24,16,'#fff','right');
    for(var i=0;i<st.lives;i++){ ctx.fillStyle='#f472b6'; var hx=16+i*20,hy=H-14; ctx.beginPath(); ctx.arc(hx-3,hy-3,4,Math.PI,0); ctx.arc(hx+3,hy-3,4,Math.PI,0); ctx.lineTo(hx,hy+5); ctx.closePath(); ctx.fill(); }
    if(st.mode==='play'&&banner>0) text('Уровень '+st.level,W/2,H/2,34,'#fde68a');
    if(st.mode==='start'){ text('Космический тир',W/2,H/2-80,36,'#fde68a'); text('Помоги зайцу угостить пришельцев',W/2,H/2-40,17); text('морковкой — они лопаются в искорки!',W/2,H/2-16,17);
      text('← → или A D — движение, Пробел — морковка',W/2,H/2+30,14,'#c7d2fe'); text('P — пауза. На телефоне — кнопки или палец',W/2,H/2+52,14,'#c7d2fe'); text('Нажмите Пробел или «Старт»',W/2,H/2+100,20,'#86efac'); }
    if(st.mode==='pause'){ ctx.fillStyle='rgba(0,0,0,.45)'; ctx.fillRect(0,0,W,H); text('Пауза',W/2,H/2,36,'#fff'); text('P или кнопка «Пауза» — продолжить',W/2,H/2+34,15,'#c7d2fe'); }
    if(st.mode==='over'){ ctx.fillStyle='rgba(0,0,0,.45)'; ctx.fillRect(0,0,W,H); text('Игра окончена',W/2,H/2-30,34,'#fde68a'); text('Очки: '+st.score+'   Рекорд: '+hs,W/2,H/2+8,18); text('Пробел или «Старт» — сыграть ещё',W/2,H/2+48,16,'#86efac'); }
  }
  // ---------- цикл ----------
  var lastT=0;
  function loop(t){ var dt=Math.min(0.05,(t-lastT)/1000||0); lastT=t; update(dt); draw(); syncUI(); requestAnimationFrame(loop); }
  function syncUI(){ var b=$('btnStart'); b.textContent=st.mode==='play'||st.mode==='pause'?'Заново':'Старт'; $('btnPause').textContent=st.mode==='pause'?'Продолжить':'Пауза'; }
  function start(){ reset(); st.mode='play'; cv.focus(); }
  function togglePause(){ if(st.mode==='play') st.mode='pause'; else if(st.mode==='pause') st.mode='play'; }
  // ---------- управление ----------
  var KM={ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',Space:'fire',ArrowUp:'fire',KeyW:'fire'};
  function playing(){ return st.mode==='play'||st.mode==='pause'||document.activeElement===cv; }
  window.addEventListener('keydown',function(e){
    var tag=(document.activeElement&&document.activeElement.tagName)||''; if(/INPUT|TEXTAREA|SELECT/.test(tag)) return;
    if(KM[e.code]){ if(playing()||e.code==='Space'&&st.mode!=='play'&&document.activeElement===cv) e.preventDefault(); if(!playing()) return; keys[KM[e.code]]=true;
      if(e.code==='Space'&&(st.mode==='start'||st.mode==='over')){ start(); } }
    if(e.code==='KeyP'&&playing()){ togglePause(); e.preventDefault(); }
  });
  window.addEventListener('keyup',function(e){ if(KM[e.code]) keys[KM[e.code]]=false; });
  var drag=null;
  function cx(e){ var r=cv.getBoundingClientRect(); return (e.clientX-r.left)/r.width*W; }
  cv.addEventListener('pointerdown',function(e){ cv.focus(); if(st.mode==='start'||st.mode==='over'){ start(); return; } if(st.mode!=='play') return; drag=cx(e); cv.setPointerCapture(e.pointerId); e.preventDefault(); });
  cv.addEventListener('pointermove',function(e){ if(drag!==null){ drag=cx(e); e.preventDefault(); } });
  ['pointerup','pointercancel'].forEach(function(n){ cv.addEventListener(n,function(){ drag=null; }); });
  cv.addEventListener('touchmove',function(e){ e.preventDefault(); },{passive:false});
  function hold(id,k){ var b=$(id); var on=function(e){ e.preventDefault(); keys[k]=true; if(k==='fire'&&(st.mode==='start'||st.mode==='over')) start(); }, off=function(){ keys[k]=false; };
    b.addEventListener('pointerdown',on); ['pointerup','pointerleave','pointercancel'].forEach(function(n){ b.addEventListener(n,off); }); b.addEventListener('contextmenu',function(e){e.preventDefault();}); }
  hold('mLeft','left'); hold('mRight','right'); hold('mFire','fire');
  $('btnStart').addEventListener('click',start); $('btnPause').addEventListener('click',function(){ togglePause(); cv.focus(); });
  $('btnSound').addEventListener('click',function(){ sound=!sound; this.setAttribute('aria-pressed',sound); this.textContent=sound?'🔊 Звук вкл.':'🔇 Звук выкл.'; if(sound) beep(660,0.1,'triangle'); });
  document.addEventListener('visibilitychange',function(){ if(document.hidden&&st.mode==='play') st.mode='pause'; });
  window.addEventListener('blur',function(){ keys={}; });
  window.addEventListener('resize',resize);
  // для автотестов
  window.__shooter={state:function(){return {mode:st.mode,score:st.score,lives:st.lives,level:st.level,aliens:aliens.filter(function(a){return a.state!=='dead';}).length,shots:shots.length};},fire:fire,start:start,setKeys:function(k){keys=k;}};
  resize(); initStars(); reset();
  try{ if(/[?&]play=1\b/.test(location.search)) start(); }catch(e){}
  requestAnimationFrame(loop);
})();
