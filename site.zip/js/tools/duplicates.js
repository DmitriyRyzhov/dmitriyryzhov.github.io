/* Поиск дубликатов: UI (логика — dup-lib.js, Excel — SheetJS). Список с счётчиками — DocumentFragment, без textarea на каждый элемент. */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var mode='dups', last=[], cur=null;
  function opt(){ return {trim:$('trim').checked, ignoreCase:$('icase').checked, ignoreEmpty:$('iempty').checked}; }
  function f(n){return n.toLocaleString('ru-RU');}
  function renderList(items){
    var box=$('outlist'), frag=document.createDocumentFragment();
    if(!items.length){ box.innerHTML='<div class="dup-empty">Ничего не найдено</div>'; return; }
    // batch via DocumentFragment + createElement (безопасно для HTML в значениях, быстро до ~50–100k)
    for(var i=0;i<items.length;i++){
      var row=document.createElement('div'); row.className='dup-item'; row.setAttribute('role','listitem');
      var v=document.createElement('span'); v.className='dup-val'; v.textContent=items[i].value;
      var c=document.createElement('span'); c.className='dup-cnt'; c.textContent='×'+items[i].count; c.title='Встречается '+items[i].count+' раз';
      row.appendChild(v); row.appendChild(c); frag.appendChild(row);
    }
    box.replaceChildren(frag);
  }
  function summary(s){
    var el=$('dupsum');
    if(mode==='dups'){
      el.innerHTML='Найдено дубликатов: <span class="dup-n">'+f(s.dupValues)+'</span> значений, лишних повторов: <span class="dup-n">'+f(s.extraCopies)+'</span>';
    } else if(mode==='unique'){
      el.innerHTML='Уникальных значений: <span class="dup-n">'+f(s.unique)+'</span>, всего вхождений: <span class="dup-n">'+f(s.total)+'</span>';
    } else {
      el.innerHTML='Встречаются один раз: <span class="dup-n">'+f(s.singles)+'</span> из <span class="dup-n">'+f(s.total)+'</span>';
    }
  }
  function run(m){
    if(m) mode=m;
    document.querySelectorAll('[data-mode]').forEach(function(b){ b.setAttribute('aria-checked',String(b.dataset.mode===mode)); });
    var t0=performance.now(), text=$('in').value;
    cur=DupLib.count(DupLib.split(text,$('sep').value),opt());
    last=DupLib.select(cur,mode,$('sort').value);
    var s=DupLib.stats(cur);
    summary(s); renderList(last);
    // скрытый textarea — для TXT/совместимости; копирование берёт plain-значения
    $('out').value=DupLib.format(last,$('outsep').value,$('counts').checked);
    $('s-total').textContent=f(s.total); $('s-unique').textContent=f(s.unique); $('s-dups').textContent=f(s.dupValues); $('s-extra').textContent=f(s.extraCopies);
    var names={dups:'Дубли',unique:'Уникальные',single:'Встречающиеся один раз'};
    $('outinfo').textContent=names[mode]+': '+f(last.length)+' · '+Math.round(performance.now()-t0)+' мс';
  }
  document.querySelectorAll('[data-mode]').forEach(function(b){ b.addEventListener('click',function(){ run(b.dataset.mode); }); });
  ['sep','trim','icase','iempty','outsep','counts','sort'].forEach(function(id){ $(id).addEventListener('change',function(){ run(); }); });
  var tm; $('in').addEventListener('input',function(){ clearTimeout(tm); tm=setTimeout(run, $('in').value.length>500000?600:200); });
  function stamp(){ var d=new Date(),p=function(n){return ('0'+n).slice(-2);}; return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
  function dl(name,blob){ var a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1000); }
  function csvCell(v){ v=String(v); return /[",;\r\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v; }
  function plain(){ return DupLib.format(last,$('outsep').value,false); }
  $('copy').addEventListener('click',function(){ var t=plain(); if(t) copyText(t); else toast('Результат пуст'); });
  $('dltxt').addEventListener('click',function(){ dl('duplicates_'+stamp()+'.txt',new Blob([$('out').value],{type:'text/plain;charset=utf-8'})); });
  $('dlcsv').addEventListener('click',function(){ dl('duplicates_'+stamp()+'.csv',new Blob(['\uFEFFvalue,count\r\n'+last.map(function(x){return csvCell(x.value)+','+x.count;}).join('\r\n')],{type:'text/csv;charset=utf-8'})); });
  $('dlxlsx').addEventListener('click',function(){
    var aoa=[['value','count']].concat(last.map(function(x){return [x.value,x.count];}));
    var wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(aoa),'Результат'); XLSX.writeFile(wb,'duplicates_'+stamp()+'.xlsx'); });
  $('clear').addEventListener('click',function(){ $('in').value=''; run(); });
  function loadFile(file){
    if(!file) return;
    var r=new FileReader();
    r.onload=function(){
      var buf=new Uint8Array(r.result);
      if(/\.(xlsx|xls|xlsm|xlsb|ods)$/i.test(file.name)||(buf[0]===0x50&&buf[1]===0x4B)||(buf[0]===0xD0&&buf[1]===0xCF)){
        try{
          var wb=XLSX.read(buf,{type:'array'}), ws=wb.Sheets[wb.SheetNames[0]];
          var rows=XLSX.utils.sheet_to_json(ws,{header:1,raw:false,defval:''}), first=$('xlcol').value==='first', vals=[];
          rows.forEach(function(row){ if(first) vals.push(row[0]===undefined?'':String(row[0])); else row.forEach(function(c){ vals.push(String(c)); }); });
          $('in').value=vals.join('\n'); $('sep').value='newline';
        }catch(e){ toast('Не удалось прочитать Excel-файл'); return; }
      } else {
        var text=new TextDecoder('utf-8').decode(buf);
        if(text.indexOf('\uFFFD')>=0){ try{ text=new TextDecoder('windows-1251').decode(buf); }catch(e){} }
        $('in').value=text.replace(/^\uFEFF/,'');
      }
      toast('Загружен файл: '+file.name); run();
    };
    r.readAsArrayBuffer(file);
  }
  $('file').addEventListener('change',function(){ loadFile(this.files[0]); this.value=''; });
  var zone=$('drop'), dc=0;
  ['dragenter','dragover'].forEach(function(ev){ document.addEventListener(ev,function(e){ e.preventDefault(); if(ev==='dragenter') dc++; zone.classList.add('dragover'); }); });
  document.addEventListener('dragleave',function(){ if(--dc<=0){ dc=0; zone.classList.remove('dragover'); } });
  document.addEventListener('drop',function(e){ e.preventDefault(); dc=0; zone.classList.remove('dragover'); if(e.dataTransfer&&e.dataTransfer.files.length) loadFile(e.dataTransfer.files[0]); });
  $('in').value='яблоко\nгруша\nяблоко\nбанан\nяблоко\nгруша\nкиви\nбанан\nяблоко';
  run();
})();
