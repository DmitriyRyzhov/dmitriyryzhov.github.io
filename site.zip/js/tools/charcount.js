/* Счётчик символов (живое обновление) */
(function(){
  'use strict';
  var t=document.getElementById('text'), $=function(id){return document.getElementById(id);};
  function upd(){
    var s=t.value;
    $('c').textContent=Array.from(s).length;
    $('cns').textContent=Array.from(s.replace(/\s/g,'')).length;
    $('w').textContent=(s.trim().match(/\S+/g)||[]).length;
    $('l').textContent=s?s.split(/\r\n|\r|\n/).length:0;
    $('b').textContent=new TextEncoder().encode(s).length;
  }
  t.addEventListener('input',upd); upd();
})();
