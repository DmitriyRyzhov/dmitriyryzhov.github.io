/* Очистка лишних пробелов и переносов строк */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var OPTS=['nbsp','tabs','spaces','trim','empty','multi','join'];
  /** Применить выбранные преобразования; порядок важен */
  function clean(s,o){
    s=s.replace(/\r\n?/g,'\n');
    if(o.nbsp) s=s.replace(/[\u00A0\u2007\u202F]/g,' ');
    if(o.tabs) s=s.replace(/\t/g,' ');
    if(o.spaces) s=s.replace(/[ \t]{2,}/g,' ');
    if(o.trim) s=s.split('\n').map(function(l){return l.trim();}).join('\n');
    if(o.empty) s=s.split('\n').filter(function(l){return l.trim()!=='';}).join('\n');
    else if(o.multi) s=s.replace(/\n([ \t]*\n){2,}/g,'\n\n');
    if(o.join) s=s.split('\n').map(function(l){return l.trim();}).filter(Boolean).join(' ');
    return s;
  }
  function run(){
    var o={}; OPTS.forEach(function(k){o[k]=$(k).checked;});
    var src=$('in').value, out=clean(src,o);
    $('out').value=out;
    $('before').textContent=src.length; $('after').textContent=out.length; $('removed').textContent=src.length-out.length;
  }
  $('in').addEventListener('input',run);
  OPTS.forEach(function(k){$(k).addEventListener('change',run);});
  $('copy').addEventListener('click',function(){copyText($('out').value);});
  run();
})();
