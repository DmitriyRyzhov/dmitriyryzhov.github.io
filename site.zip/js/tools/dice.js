/* Игральные кубики: 1–3 штуки, анимация, сумма. Случайность — crypto.getRandomValues без смещения */
(function(){
  'use strict';
  var box=document.getElementById('dice'), res=document.getElementById('res'), segs=document.querySelectorAll('.seg button');
  // индексы точек в сетке 3x3 для каждой грани
  var FACES={1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]};
  var count=1, busy=false;
  /** Честное число 1..6: отбрасываем байты >= 252 (252 = 6*42) */
  function d6(){ var a=new Uint8Array(1); do{crypto.getRandomValues(a);}while(a[0]>=252); return a[0]%6+1; }
  function make(){ var d=document.createElement('div'); d.className='die'; d.setAttribute('role','img'); for(var i=0;i<9;i++) d.appendChild(document.createElement('span')); return d; }
  function show(die,n){ die.querySelectorAll('span').forEach(function(s,i){ s.classList.toggle('on',FACES[n].indexOf(i)>=0); }); die.setAttribute('aria-label','Кубик: '+n); }
  /** Перестроить набор кубиков под выбранное количество */
  function setCount(n){
    count=n; box.innerHTML=''; for(var i=0;i<n;i++){ var d=make(); show(d,1); box.appendChild(d); }
    segs.forEach(function(b){ b.setAttribute('aria-checked', String(+b.dataset.n===n)); });
    res.innerHTML='&nbsp;';
  }
  segs.forEach(function(b){ b.addEventListener('click',function(){ if(!busy) setCount(+b.dataset.n); }); });
  document.getElementById('roll').addEventListener('click',function(){
    if(busy) return; busy=true;
    var dice=box.querySelectorAll('.die'), vals=[];
    dice.forEach(function(d){ vals.push(d6()); d.classList.remove('rolling'); void d.offsetWidth; d.classList.add('rolling'); });
    var k=0, iv=setInterval(function(){
      dice.forEach(function(d){ show(d,1+Math.floor(Math.random()*6)); }); // только для анимации
      if(++k>6){ clearInterval(iv);
        dice.forEach(function(d,i){ show(d,vals[i]); });
        var sum=vals.reduce(function(a,b){return a+b;},0);
        res.textContent = count===1 ? 'Выпало: '+sum : 'Выпало: '+vals.join(' + ')+' = '+sum;
        busy=false; }
    },80);
  });
  setCount(1);
})();
