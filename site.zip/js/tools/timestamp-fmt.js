/* Форматирование/разбор дат по шаблону с фиксированным смещением GMT (без зависимости от локальной зоны браузера).
   Токены: YYYY YY MM DD HH mm ss SSS. Смещение — в минутах (например +180 для GMT+3). */
(function(root){
  'use strict';
  var PRESETS={'YYYYMMDD':'YYYYMMDD','YYYYMMDDHHmmss':'YYYYMMDDHHmmss','YYYY-MM-DD':'YYYY-MM-DD','YYYY-MM-DD HH:mm:ss':'YYYY-MM-DD HH:mm:ss',
    'DD.MM.YYYY':'DD.MM.YYYY','DD.MM.YYYY HH:mm:ss':'DD.MM.YYYY HH:mm:ss','MM/DD/YYYY':'MM/DD/YYYY'};
  var OFFSETS=[-720,-660,-600,-570,-540,-480,-420,-360,-300,-240,-210,-180,-120,-60,0,60,120,180,210,240,270,300,330,345,360,390,420,480,525,540,570,600,630,660,720,765,780,840];
  var DAYS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'], MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  function p(n,w){ n=String(Math.abs(n)); while(n.length<(w||2)) n='0'+n; return n; }
  /** "+03:00" / "-05:30"; sep=false -> "+0300" */
  function offStr(off,sep){ return (off<0?'-':'+')+p(Math.floor(Math.abs(off)/60))+(sep===false?'':':')+p(Math.abs(off)%60); }
  /** Подпись для выпадающего списка: GMT+5:45 */
  function offLabel(off){ return 'GMT'+(off<0?'−':'+')+Math.floor(Math.abs(off)/60)+(off%60?':'+p(Math.abs(off)%60):''); }
  // порядок важен: длинные токены раньше коротких
  var TOK=/dddd|ddd|YYYY|YY|MM|DD|HH|mm|ss|SSS|WW|W|E/g;
  var DOW_RU=['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'], DOW_RU_S=['вс','пн','вт','ср','чт','пт','сб'];
  /** Календарная информация для момента ms при смещении off: день недели, ISO-неделя/год, день года */
  function info(ms,off){
    var d=new Date(ms+off*60000), wd=d.getUTCDay(), E=wd||7;
    var day=Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate());
    var thu=new Date(day+(4-E)*86400000), wy=thu.getUTCFullYear();      // ISO: неделя принадлежит году своего четверга
    var week=1+Math.floor((thu-Date.UTC(wy,0,1))/86400000/7);
    var doy=1+(day-Date.UTC(d.getUTCFullYear(),0,1))/86400000;
    return {dow:DOW_RU[wd],dowShort:DOW_RU_S[wd],E:E,week:week,weekYear:wy,doy:doy};
  }
  /** ms -> строка. fmt: ключ пресета, 'ISO', 'RFC' или пользовательский шаблон */
  function format(ms,fmt,off){
    var d=new Date(ms+off*60000); // «сдвинутое» время читаем через getUTC*
    if(fmt==='ISO') return d.toISOString().slice(0,23)+(off===0?'Z':offStr(off));
    if(fmt==='RFC') return DAYS[d.getUTCDay()]+', '+p(d.getUTCDate())+' '+MON[d.getUTCMonth()]+' '+d.getUTCFullYear()+' '+p(d.getUTCHours())+':'+p(d.getUTCMinutes())+':'+p(d.getUTCSeconds())+' '+offStr(off,false);
    var v={YYYY:p(d.getUTCFullYear(),4),YY:p(d.getUTCFullYear()%100),MM:p(d.getUTCMonth()+1),DD:p(d.getUTCDate()),HH:p(d.getUTCHours()),mm:p(d.getUTCMinutes()),ss:p(d.getUTCSeconds()),SSS:p(d.getUTCMilliseconds(),3)};
    var I=info(ms,off); v.dddd=I.dow; v.ddd=I.dowShort; v.E=I.E; v.W=I.week; v.WW=p(I.week);
    return (PRESETS[fmt]||fmt).replace(TOK,function(t){return v[t];});
  }
  /** строка -> ms или NaN. ISO/RFC содержат собственную зону (если в ISO её нет — берётся off) */
  function parse(str,fmt,off){
    str=String(str).trim();
    if(fmt==='ISO'||fmt==='RFC'){
      if(fmt==='ISO' && /^\d{4}-\d{2}-\d{2}(T[\d:.]+)?$/.test(str)){ var b=Date.parse(str.length===10?str+'T00:00:00Z':str+'Z'); return b-off*60000; }
      return Date.parse(str);
    }
    var pat=PRESETS[fmt]||fmt, keys=[], W={YYYY:4,YY:2,MM:2,DD:2,HH:2,mm:2,ss:2,SSS:3};
    var re=pat.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&').replace(TOK,function(t){ keys.push(t);
      if(t==='dddd'||t==='ddd') return '([а-яёА-ЯЁ]+)'; if(t==='W') return '(\\d{1,2})'; if(t==='E') return '([1-7])';
      return '(\\d{'+W[t]+'})'; }); // dddd/ddd/W/WW/E при разборе игнорируются (информационные)
    var m=new RegExp('^'+re+'$').exec(str); if(!m) return NaN;
    var v={YYYY:1970,MM:1,DD:1,HH:0,mm:0,ss:0,SSS:0};
    keys.forEach(function(k,i){ var n=+m[i+1]; if(!(k in v)&&k!=='YY') return; if(k==='YY') v.YYYY=2000+n; else v[k]=n; });
    var t=Date.UTC(v.YYYY,v.MM-1,v.DD,v.HH,v.mm,v.ss,v.SSS), c=new Date(t);
    if(c.getUTCMonth()!==v.MM-1||c.getUTCDate()!==v.DD||v.HH>23||v.mm>59||v.ss>59) return NaN; // несуществующая дата
    return t-off*60000;
  }
  /** Автоопределение: пробуем пресеты, ISO, RFC; затем Unix-секунды/мс. Возвращает {ms, fmt} или null */
  var AUTO=['YYYYMMDDHHmmss','YYYYMMDD','YYYY-MM-DD HH:mm:ss','YYYY-MM-DD HH:mm','YYYY-MM-DD','DD.MM.YYYY HH:mm:ss','DD.MM.YYYY HH:mm','DD.MM.YYYY','MM/DD/YYYY HH:mm:ss','MM/DD/YYYY'];
  function detect(str,off){
    for(var i=0;i<AUTO.length;i++){ var t=parse(str,AUTO[i],off); if(!isNaN(t)) return {ms:t,fmt:AUTO[i]}; }
    str=String(str).trim();
    if(/^\d{4}-\d{2}-\d{2}T/.test(str)){ t=parse(str,'ISO',off); if(!isNaN(t)) return {ms:t,fmt:'ISO 8601'}; }
    if(/^-?\d{9,13}$/.test(str)){ var n=+str; return str.replace('-','').length>=12?{ms:n,fmt:'Unix (мс)'}:{ms:n*1000,fmt:'Unix (с)'}; }
    t=Date.parse(str); if(!isNaN(t)) return {ms:t,fmt:'RFC 2822 / другой'};
    return null;
  }
  /** Сдвиг на дни/часы/минуты (дни = 24 ч, т.к. смещение фиксированное) */
  function shift(ms,d,h,m){ return ms+((+d||0)*1440+(+h||0)*60+(+m||0))*60000; }
  var lib={PRESETS:PRESETS,OFFSETS:OFFSETS,format:format,parse:parse,offLabel:offLabel,detect:detect,shift:shift,info:info};
  if(typeof module!=='undefined'&&module.exports) module.exports=lib; else root.TsFmt=lib;
})(this);
