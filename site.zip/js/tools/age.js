/* Калькулятор возраста (UI); расчёт в date-lib.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, L=DateLib;
  function n(x){return Number(x).toLocaleString('ru-RU');}
  function pl(x,a,b,c){x=Math.abs(x)%100;var y=x%10;return x>10&&x<20?c:y===1?a:y>=2&&y<=4?b:c;}
  $('on').value=L.iso(L.todayLocal());
  function calc(){
    var r=L.age($('dob').value,$('on').value), out=$('out'), err=$('err');
    if(!$('dob').value){out.hidden=true;err.textContent='';return;}
    if(!r.ok){out.hidden=true;err.textContent=r.error;return;} err.textContent=''; out.hidden=false;
    $('main').textContent=r.years+' '+pl(r.years,'год','года','лет')+' '+r.months+' '+pl(r.months,'месяц','месяца','месяцев')+' '+r.days+' '+pl(r.days,'день','дня','дней');
    $('tm').textContent=n(r.totalMonths); $('tw').textContent=n(r.totalWeeks)+(r.weeksRem?' и '+r.weeksRem+' дн.':''); $('td').textContent=n(r.totalDays); $('th').textContent=n(r.totalHours);
    $('nb').textContent=r.isBirthday?'Сегодня! 🎉':n(r.daysToBirthday)+' '+pl(r.daysToBirthday,'день','дня','дней');
    $('nbd').textContent=(r.isBirthday?'Исполняется ':'Исполнится ')+r.nextAge+' — '+r.nextBirthday.split('-').reverse().join('.')+(r.leap?' (29 февраля в невисокосный год отмечаем 28-го)':'');
    $('wd').textContent=r.weekday; $('zod').textContent=r.zodiac;
  }
  ['dob','on'].forEach(function(id){$(id).addEventListener('input',calc);$(id).addEventListener('change',calc);});
  $('today').addEventListener('click',function(){$('on').value=L.iso(L.todayLocal());calc();});
  calc();
})();
