/* Шуточный калькулятор подарка (UI); расчёт в birthday-gift-calc.js */
(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, last='';
  function rub(x,d){return Number(x).toLocaleString('ru-RU',{maximumFractionDigits:d||0})+' ₽';}
  function num(x){return Number(x).toLocaleString('ru-RU',{maximumFractionDigits:2});}
  function calc(){
    var X=+$('x').value||0,Y=+$('y').value||0,k=$('k').value,n=$('n').value,R=BdayCalc.calc(X,Y,k,n);
    $('sum').textContent=rub(R.rounded); $('exact').textContent='Точно: '+rub(R.exact,2)+' · округлённо до '+R.step+' ₽';
    $('formula').textContent='('+num(Math.max(0,X))+' / 500 + '+num(Math.max(0,Y))+' / 100) × '+num(k)+' × '+num(n)+' = ('+num(R.a)+' + '+num(R.b)+') × '+num(k*n)+' = '+num(R.exact)+' ₽';
    $('verdict').textContent=R.verdict;
    last='Скидываюсь коллеге на ДР: '+rub(R.rounded)+' (по формуле Cogle: '+$('formula').textContent+'). '+R.verdict;
  }
  ['x','y','k','n'].forEach(function(id){$(id).addEventListener('input',calc);$(id).addEventListener('change',calc);});
  $('copy').addEventListener('click',function(){copyText(last);});
  calc();
})();
