/* Подбрасывание монетки */
(function(){
  'use strict';
  var coin=document.getElementById('coin'), res=document.getElementById('res'), rot=0, busy=false, stats={h:0,t:0};
  document.getElementById('flip').addEventListener('click',function(){
    if(busy) return; busy=true; res.textContent='…';
    var a=new Uint8Array(1); crypto.getRandomValues(a); var heads=a[0]<128;
    rot += 1800 + ((heads ? 0 : 180) - rot%360 + 360)%360; // 5 оборотов + нужная сторона
    coin.style.transform='rotateY('+rot+'deg)';
    setTimeout(function(){ res.textContent=heads?'Орёл':'Решка'; heads?stats.h++:stats.t++;
      document.getElementById('stats').textContent='Орёл: '+stats.h+' · Решка: '+stats.t; busy=false; },1000);
  });
})();
