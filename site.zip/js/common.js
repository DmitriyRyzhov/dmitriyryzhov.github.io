/* Cogle — общие функции для всех страниц */
(function(){
  'use strict';
  /** Форматирование числа по-русски */
  window.fmt = function(n, d){ return Number(n).toLocaleString('ru-RU',{minimumFractionDigits:d===undefined?2:d, maximumFractionDigits:d===undefined?2:d}); };
  /** Короткое всплывающее уведомление */
  window.toast = function(msg){
    var t=document.querySelector('.toast'); if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t);}
    t.textContent=msg; t.classList.add('show'); clearTimeout(t._h); t._h=setTimeout(function(){t.classList.remove('show');},1500);
  };
  /** Копирование текста в буфер (с fallback для file://) */
  window.copyText = function(text){
    if(navigator.clipboard && window.isSecureContext){ return navigator.clipboard.writeText(text).then(function(){toast('Скопировано');}); }
    var ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select();
    try{document.execCommand('copy'); toast('Скопировано');}catch(e){toast('Не удалось скопировать');}
    ta.remove(); return Promise.resolve();
  };
})();
/* Бургер-меню в шапке */
(function(){
  var b=document.querySelector('.burger'), n=document.getElementById('site-nav'); if(!b||!n) return;
  b.addEventListener('click',function(){var o=n.classList.toggle('open'); b.setAttribute('aria-expanded',o);});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&n.classList.contains('open')){n.classList.remove('open');b.setAttribute('aria-expanded','false');b.focus();}});
})();
